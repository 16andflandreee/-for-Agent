/**
 * 自动定位 WorkBuddy 安装目录。
 *
 * ⚠ 为什么不能靠"常见路径猜"：
 *    用户可能装在任意盘符、任意目录名（中文/英文都行），
 *    甚至可能是绿色解包版。所以探测必须**自下而上**：
 *    从 exe 的文件属性 / 注册表 / 快捷方式里读真实路径，
 *    最后才退化到"扫盘符 + 常见目录名"这种兜底。
 *
 * 一个可用的 WorkBuddy 安装目录必须同时满足：
 *    ① 存在   <root>/resources/app.asar
 *    ② 存在   <root>/<exeName>        （WorkBuddy.exe 或 WorkBuddyAI.exe）
 *
 * 返回候选列表（已去重、已按可信度排序），不做唯一性断言 ——
 * 由调用方决定"唯一则自动用、多个则报错列出让用户选"。
 */
import fs from 'fs';
import path from 'path';
import os from 'os';
import { execFileSync } from 'child_process';

/** 一次目录合法性检查：asar + exe 都得在 */
export function probeRoot(root) {
  if (!root) return null;
  const r = path.resolve(root);
  if (!fs.existsSync(r)) return null;
  const asar = path.join(r, 'resources', 'app.asar');
  if (!fs.existsSync(asar)) return null;
  for (const exeName of ['WorkBuddy.exe', 'WorkBuddyAI.exe']) {
    const exe = path.join(r, exeName);
    if (fs.existsSync(exe)) {
      const st = fs.statSync(exe);
      return { root: r, exeName, asar, exe, size: st.size, mtime: st.mtime };
    }
  }
  return null;
}

/**
 * 环境变量取值，带**兜底**。
 *
 * ⚠ 不要把 process.env.APPDATA 当成一定有：在某些 shell / 服务上下文 / 精简环境里
 *   它和 ProgramData 会是 undefined，于是"开始菜单"这一整条探测路径被静默跳过 ——
 *   不报错，只是找不到。实测踩过。所以这里全部按 homedir 推算兜底。
 */
const HOME = process.env.USERPROFILE || os.homedir() || 'C:\\Users\\Default';
const ENV = {
  get APPDATA() {
    return process.env.APPDATA || path.join(HOME, 'AppData', 'Roaming');
  },
  get LOCALAPPDATA() {
    return process.env.LOCALAPPDATA || path.join(HOME, 'AppData', 'Local');
  },
  get ProgramData() {
    return process.env.ProgramData || 'C:\\ProgramData';
  },
  get ProgramFiles() {
    return process.env.ProgramFiles || 'C:\\Program Files';
  },
  get ProgramFilesX86() {
    return process.env['ProgramFiles(x86)'] || 'C:\\Program Files (x86)';
  },
  get PUBLIC() {
    return process.env.PUBLIC || 'C:\\Users\\Public';
  },
};

/** 从 exe 路径反推安装根目录（exe 就在根下） */
function fromExePath(p) {
  if (!p) return null;
  const m = String(p).match(/^(.*?)[\\/](WorkBuddy(?:AI)?\.exe)$/i);
  if (!m) return null;
  return probeRoot(m[1]);
}

// ── 来源 1：注册表（官方安装器一定会写，最可信） ──────────────────────────
/**
 * ⚠ 这里**不能用 `reg query`**：控制台程序的 stdout 按代码页编码（简中 = GBK），
 *   Node 用 utf8 解码 ⇒ 中文安装路径全变 U+FFFD ⇒ 探测静默失败。实测踩过。
 *   改用 PowerShell 读注册表，**一次调用**把所有候选路径以 Base64 抛回来（纯 ASCII），
 *   Node 侧解回 UTF-8。一次调用也顺便省掉多次进程启动的开销。
 */
function fromRegistry() {
  const ps = [
    '$ErrorActionPreference="SilentlyContinue"',
    '$keys=@(',
    '  "HKLM:\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Uninstall\\*",',
    '  "HKLM:\\SOFTWARE\\WOW6432Node\\Microsoft\\Windows\\CurrentVersion\\Uninstall\\*",',
    '  "HKCU:\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Uninstall\\*"',
    ')',
    '$paths=@()',
    'foreach($k in $keys){',
    '  Get-ItemProperty $k | Where-Object { $_.DisplayName -like "*WorkBuddy*" } | ForEach-Object {',
    '    foreach($p in @($_.InstallLocation, $_.DisplayIcon, $_.UninstallString)){',
    '      if($p){$paths += [string]$p}',
    '    }',
    '  }',
    '}',
    '$txt = ($paths -join "`n")',
    '[Convert]::ToBase64String([Text.Encoding]::UTF8.GetBytes($txt))',
  ].join('\n');

  let txt = '';
  try {
    const b64 = execFileSync('powershell.exe', ['-NoProfile', '-NonInteractive', '-Command', ps], {
      encoding: 'ascii',
      stdio: ['ignore', 'pipe', 'ignore'],
      windowsHide: true,
      timeout: 30000,
    }).trim();
    if (b64) txt = Buffer.from(b64, 'base64').toString('utf8');
  } catch {
    return []; // 没有注册表项 / 没有 PowerShell，正常
  }

  const out = [];
  for (const raw of txt.split('\n')) {
    const line = raw.trim().replace(/^"|"$/g, '');
    if (!line) continue;
    // 可能形如 "D:\path\WorkBuddy.exe" / "D:\path\" / "D:\path\uninstall.exe"
    const hit =
      fromExePath(line) ||
      probeRoot(line.replace(/[\\/][^\\/]*\.exe$/i, '')) ||
      probeRoot(line);
    if (hit) out.push(hit);
  }
  return out;
}

// ── 来源 2：正在运行的进程（应用开着时最准） ─────────────────────────────
/**
 * 同样走 PowerShell + Base64（wmic 有编码问题，且新版 Windows 已移除 wmic）。
 */
function fromProcesses() {
  const ps = [
    '$p = Get-Process -Name "WorkBuddy","WorkBuddyAI" -ErrorAction SilentlyContinue |',
    '  Where-Object { $_.Path } | ForEach-Object { $_.Path }',
    '[Convert]::ToBase64String([Text.Encoding]::UTF8.GetBytes(($p -join "`n")))',
  ].join('\n');

  let txt = '';
  try {
    const b64 = execFileSync('powershell.exe', ['-NoProfile', '-NonInteractive', '-Command', ps], {
      encoding: 'ascii',
      stdio: ['ignore', 'pipe', 'ignore'],
      windowsHide: true,
      timeout: 30000,
    }).trim();
    if (b64) txt = Buffer.from(b64, 'base64').toString('utf8');
  } catch {
    return [];
  }

  const out = [];
  for (const line of txt.split('\n')) {
    const hit = fromExePath(line.trim());
    if (hit) out.push(hit);
  }
  return out;
}

// ── 来源 3：快捷方式（开始菜单 + 桌面）─────────────────────────────────────
/**
 * ⚠ 这里有一个**静默故障**的坑，必须用 Base64 兜住：
 *   PowerShell 默认按控制台代码页（简中系统 = GBK/936）输出，
 *   而 Node 用 utf8 解码 → 中文路径里的字符全部变成 U+FFFD（替换字符），
 *   **字符串看起来"像"路径但 fs.existsSync 永远 false**，探测就漏了（还不报错）。
 *   对策：让 PowerShell 把路径转成 Base64（纯 ASCII）输出，Node 侧再解回 UTF-8。
 *   控制台代码页、chcp 设置、系统语言都不影响这条路径。
 */
function lnkTarget(lnkPath) {
  const esc = lnkPath.replace(/'/g, "''");
  const ps =
    `[Convert]::ToBase64String([Text.Encoding]::UTF8.GetBytes(` +
    `(New-Object -ComObject WScript.Shell).CreateShortcut('${esc}').TargetPath))`;
  try {
    const b64 = execFileSync('powershell.exe', ['-NoProfile', '-NonInteractive', '-Command', ps], {
      encoding: 'ascii',
      stdio: ['ignore', 'pipe', 'ignore'],
      windowsHide: true,
      timeout: 25000,
    }).trim();
    if (!b64) return '';
    return Buffer.from(b64, 'base64').toString('utf8').trim();
  } catch {
    return ''; // 单个快捷方式解析失败无所谓，继续找别的来源
  }
}

function fromShortcuts() {
  const out = [];
  const roots = [
    path.join(ENV.APPDATA, 'Microsoft', 'Windows', 'Start Menu', 'Programs'),
    path.join(ENV.ProgramData, 'Microsoft', 'Windows', 'Start Menu', 'Programs'),
    path.join(HOME, 'Desktop'),
    path.join(ENV.PUBLIC, 'Desktop'),
  ].filter((d) => d && fs.existsSync(d));

  const found = [];
  const stack = [...roots];
  let guard = 0;
  while (stack.length && guard++ < 3000) {
    const dir = stack.pop();
    let items = [];
    try {
      items = fs.readdirSync(dir, { withFileTypes: true });
    } catch {
      continue;
    }
    for (const it of items) {
      const full = path.join(dir, it.name);
      if (it.isDirectory()) {
        stack.push(full);
      } else if (/\.lnk$/i.test(it.name) && /workbuddy/i.test(it.name)) {
        found.push(full);
      }
    }
  }

  for (const lnk of found) {
    const hit = fromExePath(lnkTarget(lnk));
    if (hit) out.push(hit);
  }
  return out;
}

// ── 来源 4：兜底扫常见目录（只看浅层，绝不全盘递归）───────────────────────
/**
 * ⚠ 这一层是**最后的兜底**，覆盖不到自定义路径（比如用户装在 D:\workbuddy\xxx）。
 *   所以前面的注册表 / 进程 / 快捷方式三条路更关键 —— 它们是"读真实记录"，
 *   而这里只是"猜常见位置"。猜不到时由调用方提示用户用 --app-root 指定。
 */
function fromCommonPaths() {
  const out = [];
  const bases = [
    ENV.LOCALAPPDATA,   // 官方默认：%LOCALAPPDATA%\Programs\...
    ENV.APPDATA,
    ENV.ProgramFiles,
    ENV.ProgramFilesX86,
  ].filter(Boolean);

  const leaves = [
    'WorkBuddy',
    'WorkBuddyAI',
    'WorkBuddy\\WorkBuddyAI',
    'Programs\\WorkBuddy',
    'Programs\\WorkBuddyAI',
  ];

  for (const base of bases) {
    for (const leaf of leaves) {
      const hit = probeRoot(path.join(base, leaf));
      if (hit) out.push(hit);
    }
  }

  // 再扫各盘符根下的浅层目录名（仅一层）
  // ⚠ 不要无脑扫 A:\ 到 Z:\ —— 对不存在的盘符（尤其是空光驱/断连的网络盘），
  //   fs.existsSync 在 Windows 上可能等到超时，实测能把探测拖到十几秒。
  //   这里只在"前面都没找到"时用，且限定为真正存在的盘符。
  const shallow = ['WorkBuddy', 'WorkBuddyAI', 'workbuddy', 'workbuddy\\WorkBuddyAI'];
  for (const d of existingDrives()) {
    for (const leaf of shallow) {
      const hit = probeRoot(path.join(d, leaf));
      if (hit) out.push(hit);
    }
  }
  return out;
}

/** 真正存在的盘符（一次 PowerShell 调用问系统，避免逐个试到超时） */
let _drives = null;
function existingDrives() {
  if (_drives) return _drives;
  let list = [];
  try {
    const b64 = execFileSync(
      'powershell.exe',
      ['-NoProfile', '-NonInteractive', '-Command',
       '[Convert]::ToBase64String([Text.Encoding]::UTF8.GetBytes(((Get-PSDrive -PSProvider FileSystem).Root -join "`n")))'],
      { encoding: 'ascii', stdio: ['ignore', 'pipe', 'ignore'], windowsHide: true, timeout: 20000 }
    ).trim();
    if (b64) {
      list = Buffer.from(b64, 'base64')
        .toString('utf8')
        .split('\n')
        .map((s) => s.trim())
        .filter(Boolean);
    }
  } catch { /* 拿不到就退化成最保守的猜测 */ }
  if (list.length === 0) {
    // 兜底：常见系统盘 + 环境里出现过的盘符
    const guess = new Set(['C:\\', 'D:\\']);
    for (const v of Object.values(process.env)) {
      const m = typeof v === 'string' && v.match(/^([A-Za-z]):\\/);
      if (m) guess.add(m[1].toUpperCase() + ':\\');
    }
    list = [...guess];
  }
  _drives = list;
  return list;
}

/**
 * 主入口：按可信度依次尝试，去重后返回。
 *
 * 短路策略：前三层（注册表 / 进程 / 快捷方式）都是"读真实记录"，只要拿到了结果，
 * 就不再去猜常见目录 —— 既快，也避免猜出来的假阳性混进来。
 *
 * @returns {Array<{root:string,exeName:string,asar:string,exe:string,source:string}>}
 */
export function findAll(opts = {}) {
  const quick = !!opts.quick;
  const seen = new Set();
  const result = [];

  const push = (list, source) => {
    for (const hit of list) {
      const key = hit.root.toLowerCase();
      if (seen.has(key)) continue;
      seen.add(key);
      result.push({ ...hit, source });
    }
  };

  push(fromRegistry(), '注册表');
  push(fromProcesses(), '运行中的进程');
  push(fromShortcuts(), '开始菜单/桌面快捷方式');

  // 前三层已经找到就收工，不浪费时间猜路径
  if (result.length > 0 || quick) return result;

  push(fromCommonPaths(), '常见目录');

  return result;
}

export default { findAll, probeRoot };
