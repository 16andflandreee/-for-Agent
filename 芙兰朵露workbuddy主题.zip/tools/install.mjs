/**
 * 芙兰朵露主题 · WorkBuddy 安装器
 * ═══════════════════════════════════════════════════════════════════════════
 *
 *  给 AI / 自动化使用。人类请直接看 README.md。
 *
 *  本脚本做一件事：把主题**原地注入** WorkBuddy 的 app.asar，严格不动其它文件。
 *
 * ── ⚠⚠ 动手前必读：这为什么是危险的 ⚠⚠ ────────────────────────────────────
 *
 *  WorkBuddy 的 asar 有【两层】完整性校验。**只修一层，应用会直接 FATAL 退出**，
 *  表现是点图标毫无反应 / 一闪而过。两层的细节：
 *
 *   第一层  逐文件校验（asar_file_validator.cc）
 *      asar header 里每个条目的 `integrity.hash` == sha256(该文件内容)。
 *      而且 `integrity.blocks[0]` 是**同一个值，两处都要改**。
 *
 *   第二层  整包校验（asar_util.cc "Integrity check failed for asar archive"）
 *      exe 里烘焙了一份期望值：sha256(整个 asar header 字节)。
 *      改 header（哪怕只是为了同步第一层的哈希）就会让这一层失败。
 *
 *  ⇒ 于是必须【三处同步】：① index.html 内容 ② header 的 integrity.hash + blocks[0]
 *    ③ exe 里的期望值。三者都是 64 位 hex，所以全部**等长替换**。
 *
 * ── 为什么内容必须等长 ────────────────────────────────────────────────────
 *  asar header 记录每个文件的 size / offset，且下一个文件的 offset 正好等于上一个
 *  结束位置（实测 gap = 0）。**改长度会让后面 ~2 万个文件的偏移全部错位**。
 *  所以注入 index.html 时要：删注释腾空间 → 插 link/script → 末尾补空格凑回原长。
 *
 * ── 安全护栏（本脚本内置，请不要绕过） ────────────────────────────────────
 *   · 写前闸门：app.asar / exe 必须先能拿到写权限，否则**一个字节都不动**
 *   · 三件套备份：原版 index.html + 原 header + 原 exe，全部落到 backup 目录
 *   · 写后回读：按**真规则**重算两层哈希（不是"我写进去了所以应该对"）
 *   · 失败自动回滚：任何一步验证不过，按真实字节区间原样盖回去
 *
 * ── 用法 ──────────────────────────────────────────────────────────────────
 *   node tools/install.mjs                 自动探测安装目录并安装
 *   node tools/install.mjs --check         只体检，不改任何东西（先跑这个！）
 *   node tools/install.mjs --uninstall     完全卸载还原
 *   node tools/install.mjs --reinstall     先还原再重装
 *   node tools/install.mjs --app-root="D:/path/to/WorkBuddy"   手动指定目录
 *   node tools/install.mjs --cn / --intl   探测到多版本时，指定国内版 / 国际版
 *   node tools/install.mjs --reap          安装期间顺手把冒出来的应用再关掉
 *   node tools/install.mjs --dry           试运行：全部计算与校验都做，但不写盘
 *   node tools/install.mjs --adopt         已装主题但原版备份丢失时，从当前状态反推近似原版
 *                                          （⚠ 有损，见脚本内注释，谨慎使用）
 *
 *   环境变量（离线自测 / 调试用，日常不需要）：
 *     WB_APP_ROOT / WB_EXE_NAME / WB_BACKUP_DIR / WB_EXE_TRY / WB_DRY=1
 */
import fs from 'fs';
import path from 'path';
import crypto from 'crypto';
import { spawnSync } from 'child_process';
import { fileURLToPath } from 'url';
import { findAll, probeRoot } from './locate.mjs';

// ── 路径：全部相对本文件定位，不依赖任何硬编码机器路径 ────────────────────
const __dirname = path.dirname(fileURLToPath(import.meta.url));
const PKG_ROOT = path.resolve(__dirname, '..');           // 压缩包根目录
const SKIN_DIR = path.join(PKG_ROOT, 'skin').replace(/\\/g, '/');
const DEFAULT_BACKUP_DIR = path.join(PKG_ROOT, 'backup').replace(/\\/g, '/');

// ── 参数解析 ──────────────────────────────────────────────────────────────
function parseArgs(argv) {
  let appRoot = null;
  let appKey = null;
  for (const a of argv) {
    let m;
    if ((m = a.match(/^--app-root=(.+)$/))) appRoot = m[1].replace(/^["']|["']$/g, '');
    else if (a === '--cn') appKey = 'cn';
    else if (a === '--intl') appKey = 'intl';
    else if (/^(cn|intl)$/.test(a)) appKey = a;
  }
  const dry = argv.includes('--dry') || process.env.WB_DRY === '1';
  const adopt = argv.includes('--adopt');
  let mode = argv.includes('--uninstall')
    ? 'uninstall'
    : argv.includes('--check')
      ? 'check'
      : argv.includes('--reinstall')
        ? 'reinstall'
        : 'install';
  // --adopt 的语义是"接管当前已装状态并换成这一版"，本质上就是重装。
  // 不自动隐含的话，会因为"已装 + 路径不同"被 install 分支拦下来（逻辑自相矛盾）。
  if (adopt && mode === 'install') mode = 'reinstall';
  return { appRoot, appKey, mode, reap: argv.includes('--reap'), dry, adopt };
}

const ARGS = parseArgs(process.argv.slice(2));

// ── 目标应用：自动探测 ────────────────────────────────────────────────────
/**
 * 探测顺序：--app-root 显式指定 > 环境变量 > 自动扫描。
 * 自动扫描返回多个候选时**不猜**，列出来让调用方决定 —— 装错版本比装不上更糟。
 */
function resolveApp() {
  const explicit = ARGS.appRoot || process.env.WB_APP_ROOT;
  if (explicit) {
    const hit = probeRoot(explicit);
    if (!hit) {
      console.error(`❌ --app-root 指向的目录不是有效的 WorkBuddy 安装目录：${explicit}`);
      console.error('   该目录下必须同时存在 resources/app.asar 和 WorkBuddy.exe（或 WorkBuddyAI.exe）。');
      process.exit(1);
    }
    return { ...hit, source: '手动指定' };
  }

  const all = findAll({ quick: false });
  if (all.length === 0) {
    console.error('❌ 没有找到任何 WorkBuddy 安装目录。');
    console.error('   请用 --app-root="<安装目录>" 手动指定（目录里应有 WorkBuddy.exe 和 resources/app.asar）。');
    process.exit(1);
  }
  if (all.length > 1 && ARGS.appKey) {
    const want = ARGS.appKey === 'cn' ? 'WorkBuddy.exe' : 'WorkBuddyAI.exe';
    const pick = all.find((a) => a.exeName === want);
    if (pick) return pick;
    console.error(`⚠ 指定了 --${ARGS.appKey}（期望 ${want}），但没找到对应安装；候选如下：`);
    for (const a of all) console.error(`   · ${a.root}  (${a.exeName}, 来自${a.source})`);
    process.exit(1);
  }
  if (all.length > 1) {
    // 多个候选：如果指向同一个 root 就不算冲突（去重已做），仍是多个说明真装了两版
    console.error('❌ 探测到多个 WorkBuddy 安装，无法确定要装哪个：');
    for (const a of all) console.error(`   · ${a.root}  (${a.exeName}, 来自${a.source})`);
    console.error('\n   请用 --app-root="<上面某一个>" 明确指定。');
    process.exit(1);
  }
  return all[0];
}

const APP = resolveApp();
const APP_NAME = APP.exeName === 'WorkBuddy.exe' ? '国内版' : '国际版';

// ── 仅用于离线回归自测的路径覆盖 ──────────────────────────────────────────
// 把 app.asar + exe 拷到临时目录，用 WB_APP_ROOT 指过去，就能在**不碰真实安装**
// 的前提下把整条「三处同步写入 + 双层回读校验 + rollback」跑一遍。
if (process.env.WB_APP_ROOT) APP.root = process.env.WB_APP_ROOT.replace(/\\/g, '/').replace(/\/+$/, '');
const EXE_NAME = process.env.WB_EXE_NAME || APP.exeName;

const { mode, reap, dry } = ARGS;

const ASAR = `${APP.root}/resources/app.asar`;
const EXE = `${APP.root}/${EXE_NAME}`;
const TARGET = '/renderer/index.html';
const BACKUP_DIR = (process.env.WB_BACKUP_DIR || DEFAULT_BACKUP_DIR).replace(/\\/g, '/');
const HDR_BAK = path.join(BACKUP_DIR, 'asar-header.original.bin');
const EXE_BAK = path.join(BACKUP_DIR, `orig.${EXE_NAME}`);

// 「这条 index.html 是不是被我们注入过」的判据。
// ⚠ 必须独立于 SKIN_DIR：早期版本用 SKIN_DIR 的目录名当标记，结果换了个解压路径
//   标记就失效了 —— 明明装着主题，脚本却认为"未装"，然后重复注入 / 拒绝安装。
//   现在用【注入内容里必然出现、且绝不会被别的工具碰巧写入】的两个特征做与路径无关的判据。
const HTML_ATTR = 'data-wb-flandre';
const isSkinnedHtml = (t) =>
  t.includes(HTML_ATTR) || /file:\/\/\/[^"']*\/theme\.css/.test(t);

const INJECT =
  `<link rel="stylesheet" href="file:///${SKIN_DIR}/theme.css">` +
  `<script src="file:///${SKIN_DIR}/client.js"></script>`;

const sha256 = (buf) => crypto.createHash('sha256').update(buf).digest('hex');

/** 同步睡眠（不新起进程）：Atomics.wait 在 Node 主线程上是允许的 */
const sleep = (ms) => Atomics.wait(new Int32Array(new SharedArrayBuffer(4)), 0, 0, ms);

/**
 * 把应用"再关一次"。
 *
 * 为什么需要：实测出现过 —— 关掉应用后探针明明通过（exe 可写），1 秒后真正写 exe
 * 时又 EBUSY。要么是杀软实时防护在被强杀的那一瞬扫描这个 200MB 的镜像，
 * 要么是有看门狗把它又拉起来了。两种情况下"再关一次 + 重试"都能过。
 */
function reapApp(label) {
  console.log(`   [reap] ${label}：强制结束 ${EXE_NAME} …`);
  spawnSync('taskkill', ['/F', '/T', '/IM', EXE_NAME], { stdio: 'ignore' });
  sleep(1200);
}

/** 关闭 exe 写句柄并置空（置空很重要：rollback 靠它判断"句柄还在不在"） */
function closeExe() {
  try {
    if (fdExe !== null) fs.closeSync(fdExe);
  } catch {
    /* 已关闭 */
  }
  fdExe = null;
}

/**
 * 写 exe，遇 EBUSY/EPERM 就重试（必要时先再关一次应用）。
 * 幂等：`patchExeViaFd` 会跳过已经是新值的槽位，所以重试不会写坏。
 */
function writeExeWithRetry(newHeaderHash) {
  for (let i = 1; i <= EXE_TRY; i++) {
    try {
      return patchExeViaFd(fdExe, newHeaderHash);
    } catch (err) {
      const busy = err.code === 'EBUSY' || err.code === 'EPERM' || err.code === 'EACCES';
      if (!busy || i === EXE_TRY) throw err;
      console.log(`   [${i}/${EXE_TRY}] 写 exe 失败（${err.code}），准备重试…`);
      closeExe();
      if (reap) reapApp('重试期间');
      else sleep(1000);
      for (let k = 0; k < 5; k++) {
        try {
          fdExe = fs.openSync(EXE, 'r+');
          break;
        } catch {
          sleep(1000);
        }
      }
      if (fdExe === null) throw err;
    }
  }
  throw new Error('写 exe 重试耗尽');
}
const ascii = (s) => Buffer.from(s, 'ascii');

// ── asar 底层 ─────────────────────────────────────────────────────────────
function openAsar(rw = false) {
  const fd = fs.openSync(ASAR, rw ? 'r+' : 'r');
  const b = Buffer.alloc(16);
  fs.readSync(fd, b, 0, 16, 0);
  const hs = b.readUInt32LE(12); // ← offset 12 是 header 长度，不是 JSON 起点（中间有 padding）
  const pad = (4 - (hs % 4)) % 4;
  const hb = Buffer.alloc(hs);
  fs.readSync(fd, hb, 0, hs, 16);
  return { fd, hs, pad, hb, dataStart: 16 + hs + pad };
}

function entryOf(json, p) {
  let cur = json;
  for (const seg of p.split('/').filter(Boolean)) {
    cur = cur.files[seg];
    if (!cur) throw new Error('asar 里找不到 ' + p);
  }
  return cur;
}

function readAt(fd, pos, len) {
  const buf = Buffer.alloc(len);
  fs.readSync(fd, buf, 0, len, pos);
  return buf;
}

/**
 * 第一层：把 header 里 target 条目的 integrity.hash 与 blocks[0] 改成 newHex。
 * 严格等长（只动 128 个 hex 字符），headerSize 不变。
 */
function patchHeaderEntryHash(hb, e, oldHex, newHex) {
  if (oldHex.length !== 64 || newHex.length !== 64) throw new Error('哈希必须都是 64 位 hex');
  const anchor = ascii(
    `"size":${e.size},"offset":"${e.offset}","integrity":{"algorithm":"${e.integrity.algorithm}","hash":"`
  );
  const idx = hb.indexOf(anchor);
  if (idx < 0) throw new Error('找不到目标条目锚点');
  if (hb.indexOf(anchor, idx + 1) >= 0) throw new Error('锚点不唯一，拒绝改写');

  const hashPos = idx + anchor.length;
  if (hb.toString('ascii', hashPos, hashPos + 64) !== oldHex) throw new Error('锚点后不是预期旧哈希');

  const bAnchor = ascii('"blocks":[');
  const bIdx = hb.indexOf(bAnchor, hashPos + 64);
  if (bIdx < 0) throw new Error('找不到 blocks 数组');
  const bHashPos = bIdx + bAnchor.length + 1;
  if (hb.toString('ascii', bHashPos, bHashPos + 64) !== oldHex) throw new Error('blocks[0] 不是预期旧哈希');
  if (hb.toString('ascii', bHashPos + 64, bHashPos + 65) !== '"') {
    throw new Error('blocks 结构不符（多块大文件？），拒绝改写');
  }

  hb.write(newHex, hashPos, 64, 'ascii');
  hb.write(newHex, bHashPos, 64, 'ascii');
}

/**
 * 第二层：定位 exe 里指向 resources\app.asar 的期望哈希槽位。
 *
 * ⚠ 两个坑，都踩过：
 *  1) 这里**必须精确匹配整条 JSON 清单条目**，不能用「找到 app.asar 再往后找
 *     "value":"」那种模糊启发式：`default_app.asar` 里就含 `app.asar` 子串，
 *     附近还有别的 value 槽位，模糊匹配会写错地址（exe 里写错 64 字节 = 应用起不来）。
 *  2) 哈希的字节位置**不要用「m[0].length 减常数」去算** —— 一开始写的是
 *     `m.index + m[0].length - 65`，差一位；结果写到哈希的第 2 个字符起，
 *     把结尾的 `"` 也盖掉了，清单 JSON 直接失效。
 *     正确做法是用 `m[0].indexOf(m[1])` 直接定位捕获组在整串里的下标，零算术。
 *
 * 实测两版的清单都有 3 条：app.asar(SHA256) / default_app.asar(sha256) /
 * app.asar(sha256 小写) —— 前两条 alg 大小写不同，所以正则要同时接受。
 */
const EXE_SLOT_RE =
  /\{"file":"resources\\\\app\.asar","alg":"(?:SHA256|sha256)","value":"([0-9a-f]{64})"\}/g;

function findExeHashSlots(exeBuf) {
  const s = exeBuf.toString('latin1'); // latin1 = 1 字符 1 字节，下标即字节偏移
  const slots = [];
  EXE_SLOT_RE.lastIndex = 0;
  let m;
  while ((m = EXE_SLOT_RE.exec(s))) {
    slots.push({ hexPos: m.index + m[0].indexOf(m[1]), hex: m[1] });
  }
  return slots;
}

function exeExpectedHashes(buf) {
  return findExeHashSlots(buf || fs.readFileSync(EXE));
}

/** 确认 exe 里的 app.asar 期望槽位就是 2 个（多或少都说明结构变了，拒绝改写） */
function assertExeSlots(slots, hdrHash) {
  if (slots.length !== 2) {
    throw new Error(
      `exe 里指向 resources\\app.asar 的完整性槽位应为 2 个，实测 ${slots.length} 个 —— ` +
        `说明 ${APP_NAME} 的 exe 结构变了，拒绝改写。`
    );
  }
  const first = slots[0].hex;
  for (const s of slots) {
    if (s.hex !== first) throw new Error('exe 里两个 app.asar 槽位的期望值不一致，拒绝改写。');
  }
  if (hdrHash && first !== hdrHash) {
    throw new Error(
      `exe 期望值(${first.slice(0, 8)}…) 与当前 header sha256(${hdrHash.slice(0, 8)}…) 不一致 —— ` +
        `说明 exe 或 asar 已被别的工具改过，先跑 --check 排查。`
    );
  }
  return { count: slots.length, current: first };
}

/**
 * 写 exe 里的期望哈希 —— **用调用方一直握着的那个写句柄**（fdExe）。
 *
 * 为什么不每次临时开：因为"探针通过 → 1 秒后真写时被抢锁"这个竞态真实发生过
 * （2026-09-19 日志：exe 已可写 ✅ → EBUSY）。握着写句柄时：
 *   ① 别的进程再也拿不到写权限，抢锁无从谈起；
 *   ② Windows 不允许把带写句柄的文件映射成可执行镜像 ⇒ 应用在这期间也无法被
 *      重新启动，等于把"asar 已改、exe 没改"的窗口焊死了。
 */
function patchExeViaFd(fdExe, newHeaderHash) {
  const size = fs.fstatSync(fdExe).size;
  const buf = Buffer.alloc(size);
  fs.readSync(fdExe, buf, 0, size, 0);
  const slots = findExeHashSlots(buf);
  if (slots.length !== 2) throw new Error(`exe 槽位数异常：${slots.length}`);

  let changed = 0;
  for (const s of slots) {
    if (s.hex === newHeaderHash) continue;
    fs.writeSync(fdExe, Buffer.from(newHeaderHash, 'ascii'), 0, 64, s.hexPos);
    changed++;
  }
  fs.fsyncSync(fdExe); // 落盘 —— 也是"确实写进去了"的硬证据

  const after = Buffer.alloc(size);
  fs.readSync(fdExe, after, 0, size, 0);
  if (after.length !== size) throw new Error('exe 大小改变了！');
  const slots2 = findExeHashSlots(after);
  if (slots2.length !== slots.length) throw new Error('exe 槽位数量变了！');
  for (const s of slots2) {
    if (s.hex !== newHeaderHash) throw new Error('exe 槽位未全部更新到新哈希');
  }
  return { count: slots.length, changed };
}

// ── 内容生成：把主题注入原版 index.html（严格等长） ───────────────────────
function buildSkinned(orig) {
  // 目标长度 = 传入内容的字节数（要与 asar header 记录的 size 完全一致）
  const origLen = Buffer.byteLength(orig, 'utf8');
  // 但"内容起点"要去掉尾部补位空白 —— 否则从已装状态反推出来的备份（--adopt）
  // 末尾已经带了一串空格，再往里插东西必然超长。
  // 对真正的原版，尾部本来没有多余空白，这一步是空操作。
  const base = orig.replace(/\s+$/, '');

  // 1. 给 <html> 挂主题标记（parse 即生效，不依赖 JS —— CSS 全限定在这个属性下，
  //    只靠 script 打标记的话，script 一失败主题就整体全废且难排查）
  if (!/<html[\s>]/.test(base)) throw new Error('找不到 <html> 标签');
  let out = base.replace(/<html(?=[\s>])/, `<html ${HTML_ATTR}`);

  // 2. 删掉那段超长的中文注释（纯说明，删掉不影响功能）腾空间。
  //    注意：**允许它不存在**。场景：这份原版是从"已装状态"反推出来的（--adopt），
  //    而注入时那段注释就已经被删掉了 —— 此时没有注释可删，不是错误。
  const COMMENT_RE = /<!--\s*首屏 account snapshot[\s\S]*?-->/;
  out = out.replace(COMMENT_RE, '');

  // 3. 在 </head> 前插入引用（落在所有官方 CSS 之后，层叠顺序天然优先）
  if (!out.includes('</head>')) throw new Error('找不到 </head>');
  out = out.replace('</head>', INJECT + '</head>');

  // 4. 末尾补空格凑回原长
  const len = Buffer.byteLength(out, 'utf8');
  if (len > origLen) throw new Error(`插入后 ${len} 字节 > 原长 ${origLen} 字节，空间不足`);
  out += ' '.repeat(origLen - len);

  const buf = Buffer.from(out, 'utf8');
  if (buf.length !== origLen) throw new Error(`长度校验失败：${buf.length} != ${origLen}`);
  if (!isSkinnedHtml(out) || !out.includes(HTML_ATTR)) throw new Error('内容校验失败');
  return buf;
}

/** 取最早的那份原版备份（排除 skinned 之类的中间产物） */
function findOriginalBackup() {
  if (!fs.existsSync(BACKUP_DIR)) return null;
  const list = fs
    .readdirSync(BACKUP_DIR)
    .filter((f) => /^renderer-index\.html\.\d{14}\.bak$/.test(f))
    .sort();
  if (list.length) return path.join(BACKUP_DIR, list[0]);
  // 手工放的原版备份也认
  const plain = path.join(BACKUP_DIR, 'renderer-index.html.original.bak');
  return fs.existsSync(plain) ? plain : null;
}

/**
 * 找不到原版备份时，去"很可能有"的地方找一找 —— 主题以前可能是用别的工具、
 * 在别的目录装的（比如开发时的工程目录）。
 *
 * ⚠ 这里**必须逐个验证版本匹配**，不能只看"长得像备份"：
 *   国内版 / 国际版的 index.html 长度**都是 15561 字节**，但内容不同，
 *   拿错版本的备份去还原 = 把一个不属于这个发行版的 index.html 塞进去，
 *   虽然长度对得上、哈希也能自洽，但页面结构是错的（可能白屏或功能异常）。
 *
 * ── 判据为什么不能是"注入后与当前内容相等" ────────────────────────────────
 *   第一版我就是这么写的，**错的**。因为注入结果里含有**当次运行的 SKIN_DIR 绝对路径**
 *   （`file:///D:/.../theme.css`），而当前 asar 里记录的是**历史上某一次**的路径 ——
 *   除非两次路径恰好相同，否则永远比不相等，于是"备份明明存在却找不到"。
 *
 *   改成**路径无关的归一化比对**：把两边都做同一套"抹掉主题痕迹"的处理
 *   （去掉 html 上的主题属性、去掉注入的 link/script、去掉尾部补齐的空格），
 *   抹完还一致 ⇒ 是同一个版本的骨架 ⇒ 这个备份能用。
 *
 * @param {Buffer} curSkinBuf 当前 asar 里 index.html 的字节（已装状态）
 * @returns {string[]} 匹配的备份路径
 */
function searchOtherBackups(curSkinBuf) {
  const hits = [];
  const roots = [];
  const home = process.env.USERPROFILE || '';
  for (const d of ['Desktop', 'Downloads', 'Documents']) {
    if (home) roots.push(path.join(home, d));
  }
  for (const drive of ['C:\\', 'D:\\', 'E:\\', 'F:\\']) {
    if (fs.existsSync(drive)) roots.push(drive);
  }

  /**
   * 抹掉主题痕迹，得到"骨架"。
   * 对「已装内容」和「候选原版」用同一套规则，结果就与注入路径无关了。
   */
  const skeleton = (t) =>
    t
      // 去掉注入的 link / script（路径任意）
      .replace(/<link[^>]*href="file:\/\/\/[^"]*\/theme\.css"[^>]*>/g, '')
      .replace(/<script[^>]*src="file:\/\/\/[^"]*\/client\.js"[^>]*><\/script>/g, '')
      // 去掉 <html> 上的主题属性
      .replace(/(<html)\s+data-wb-flandre\b/g, '$1')
      // 去掉尾部为凑长度补的空格
      .replace(/\s+$/, '');

  const target = skeleton(curSkinBuf.toString('utf8'));

  /** 硬校验：骨架必须与目标一致 */
  const matchesTarget = (p) => {
    try {
      return skeleton(fs.readFileSync(p, 'utf8')) === target;
    } catch {
      return false;
    }
  };

  /** 候选备份的基本形态检查（长度等长 + 不含主题痕迹） */
  const looksLikeBak = (p) => {
    try {
      const st = fs.statSync(p);
      if (st.size !== curSkinBuf.length) return false; // 原版与已装版本严格等长
      const t = fs.readFileSync(p, 'utf8');
      return !t.includes(HTML_ATTR) && !/file:\/\/\/[^"']*\/theme\.css/.test(t);
    } catch {
      return false;
    }
  };

  // 搜索深度上限 3 层（D:\a\b\ 这种布局要够得到），并加总时长上限防止拖慢。
  const DEADLINE = Date.now() + 20000; // 最多找 20 秒，找不到就算了
  const walk = (dir, depth) => {
    if (depth > 3 || Date.now() > DEADLINE) return;
    let items = [];
    try {
      items = fs.readdirSync(dir, { withFileTypes: true });
    } catch {
      return;
    }
    for (const it of items) {
      if (Date.now() > DEADLINE) return;
      const full = path.join(dir, it.name);
      if (it.isDirectory()) {
        if (/^(node_modules|\.git|Windows|Program Files.*|AppData|\$RECYCLE\.BIN|System Volume Information)$/i.test(it.name)) continue;
        walk(full, depth + 1);
      } else if (/^renderer-index\.html\.\d+\.bak$/i.test(it.name) && looksLikeBak(full)) {
        if (matchesTarget(full)) hits.push(full);
      }
    }
  };

  for (const r of roots) walk(r, 0);
  return [...new Set(hits)];
}

// ── 主流程 ────────────────────────────────────────────────────────────────
console.log(`╔═══ WorkBuddy × 芙兰朵露 · 目标 = ${APP_NAME} / ${EXE_NAME}`);
console.log(`║  来源 : ${APP.source}`);
console.log(`║  asar : ${ASAR}`);
console.log(`║  exe  : ${EXE}`);
console.log(`║  备份 : ${BACKUP_DIR}`);
console.log(`╚═══ 模式 = ${mode}`);

if (!fs.existsSync(ASAR)) {
  console.error('❌ 找不到 app.asar，检查安装路径。');
  process.exit(1);
}

const { fd, hs, hb, dataStart } = openAsar(mode !== 'check');
const json = JSON.parse(hb.toString('utf8').replace(/\0+$/, ''));
const e = entryOf(json, TARGET);
const at = dataStart + parseInt(e.offset, 10);
const cur = readAt(fd, at, e.size);

const contentHex = sha256(cur);
const isSkinned = isSkinnedHtml(cur.toString('utf8'));
const headerHash = sha256(hb);
// exe 只读一次，后续所有槽位定位与回滚快照都用这一份 buffer
const exeBuf0 = fs.readFileSync(EXE);
const exeSlots = exeExpectedHashes(exeBuf0);

console.log('\n═══ 体检 ═══');
console.log('index.html  : size=' + e.size, 'offset=' + e.offset);
console.log('');
console.log('【一层】逐文件校验');
console.log('  内容 sha256   :', contentHex);
console.log('  header 记录   :', e.integrity.hash);
console.log('  状态          :', contentHex === e.integrity.hash ? '✅ 一致' : '❌ 不一致 → 会 FATAL');
console.log('');
console.log('【二层】整包(header)校验');
console.log('  sha256(header):', headerHash);
for (const s of exeSlots) console.log('  exe 期望值    :', s.hex, `@${s.hexPos}`);
console.log('  状态          :', exeSlots.length > 0 && exeSlots.every((s) => s.hex === headerHash) ? '✅ 一致' : '❌ 不一致 → 会 FATAL');
console.log('  槽位数        :', exeSlots.length, exeSlots.length === 2 ? '✅' : '⚠ 应为 2');
console.log('  主题          :', isSkinned ? '已装' : '未装');
console.log('  html 标记     :', cur.toString('utf8').includes(HTML_ATTR) ? '已在 <html> 上' : '未在 <html> 上');

if (mode === 'check') {
  fs.closeSync(fd);
  const ok =
    contentHex === e.integrity.hash &&
    exeSlots.length === 2 &&
    exeSlots.every((s) => s.hex === headerHash);
  console.log('\n结论：' + (ok ? '两层校验都能通过，应用可正常启动。' : '存在校验不通过，应用会起不来！'));
  process.exit(ok ? 0 : 1);
}

try {
  assertExeSlots(exeSlots, mode === 'check' ? null : headerHash);
} catch (err) {
  console.error('\n❌ ' + err.message);
  fs.closeSync(fd);
  process.exit(1);
}

// ── 写前闸门：应用运行时 exe 被 Windows 锁住，根本写不进去 ────────────────
// 实测（国内版 5.5.6）：WorkBuddy 正在运行时，app.asar 可以写，但
// WorkBuddy.exe 一开 'r+' 就是 EBUSY —— 正在运行的可执行镜像无法就地改写。
// 而二层校验的期望值就烘焙在 exe 里，必须三处一起改，所以**只要 exe 写不了
// 就一个字节都别动**。否则会走到"asar 改了、exe 没改"，然后靠 rollback 兜底
// （第一次就是这么踩的：回滚成功但报错信息很吓人）。
// 这里在动任何字节之前先试开一次 r+，拿不到就干净退出。
function probeWritable(p, label) {
  try {
    fs.closeSync(fs.openSync(p, 'r+'));
    return true;
  } catch (err) {
    console.error(`\n❌ ${label} 被占用，写不进去（${err.code}）。`);
    console.error(`   原因：正在运行的 ${APP_NAME} 会把 ${EXE_NAME} 锁住，`);
    console.error('         而二层完整性校验的期望值就烘焙在 exe 里 —— 三处必须一起改。');
    console.error(`   处理：完全退出 WorkBuddy（含托盘图标），再重新运行本命令。`);
    console.error('   本次**未做任何修改**，应用状态不变。');
    return false;
  }
}
if (!probeWritable(ASAR, 'app.asar')) {
  fs.closeSync(fd);
  process.exit(1);
}

// ── exe：不只是"探一下"，而是把可写句柄一直握到真正写入那一刻 ─────────────
// 实测踩过（2026-09-19 20:22）：探针明明通过了、日志还打印了"exe 已可写 ✅"，
// 1 秒后真写 exe 却 EBUSY。原因是应用被强杀的那一瞬，杀软的实时防护会去扫描
// 这个 200MB 的镜像（或有看门狗把它重新拉起来），短短一秒内就把锁又拿走了。
// 对策两手一起上：
//   ① 握住写句柄不放 —— 见 patchExeViaFd 的注释；
//   ② 拿不到 / 写不进就重试，重试前可以顺手把冒出来的应用再关一次（--reap）。
const EXE_TRY = Number(process.env.WB_EXE_TRY || 30); // 默认 30 次（约 30 秒，够杀软扫完 200MB）
let fdExe = null;
let lastErr = null;
for (let i = 1; i <= EXE_TRY; i++) {
  try {
    fdExe = fs.openSync(EXE, 'r+');
    break;
  } catch (err) {
    if (err.code !== lastErr) {
      console.error(`\n   [${i}/${EXE_TRY}] ${EXE_NAME} 暂时写不进（${err.code}），重试中…`);
      if (i === 1) {
        console.error(
          reap
            ? '    （--reap 已开启：期间会把冒出来的应用再关一次）'
            : '    （若应用正在运行，请完全退出它 —— 托盘图标右键退出，不是点 × ）'
        );
      }
      lastErr = err.code;
    } else if (i % 5 === 0) {
      console.error(`   [${i}/${EXE_TRY}] 仍在重试…`);
    }
    if (reap && i % 3 === 0) reapApp('重试期间又关一次');
    else sleep(1000);
  }
}
if (!fdExe) {
  console.error(`\n❌ ${EXE_NAME} 一直被占用，写不进去（最后一次 ${lastErr}）。`);
  console.error(`   原因：正在运行的 ${APP_NAME} 会把 ${EXE_NAME} 锁住，`);
  console.error('         而二层完整性校验的期望值就烘焙在 exe 里 —— 三处必须一起改。');
  console.error('   处理：完全退出 WorkBuddy（含托盘图标），再重新运行本命令。');
  console.error('   本次**未做任何修改**，应用状态不变。');
  fs.closeSync(fd);
  process.exit(1);
}
console.log(`已取得 ${EXE_NAME} 的写句柄（将一直握到写盘完成）✅`);

// 再确认"写"真的可行（不只是"能打开"）：把第一个槽位的现值**原样写回去**，
// 等于一次空操作，但它证明"写入这一刻不会被拒绝"。把风险挡在动 asar 之前 ——
// 否则会走到"asar 已改、exe 写不进"，虽然 rollback 能兜住，但没必要冒这个险。
try {
  const s0 = exeSlots[0];
  fs.writeSync(fdExe, Buffer.from(s0.hex, 'ascii'), 0, 64, s0.hexPos);
  fs.fsyncSync(fdExe);
  console.log('exe 空写自检通过（写权限可用）✅');
} catch (err) {
  console.error(`\n❌ ${EXE_NAME} 能打开但写不进（${err.code}）—— 有别的东西正在占用它。`);
  console.error('   本次**未做任何修改**，应用状态不变。');
  closeExe();
  fs.closeSync(fd);
  process.exit(1);
}

// 备份（只在第一次安装时做）
fs.mkdirSync(BACKUP_DIR, { recursive: true });
let origBak = findOriginalBackup();
if (!origBak) {
  // 首次安装：当前内容必须还是原版，直接把它存成原版备份（省掉手工一步）
  if (isSkinned) {
    // 已经是主题状态，但本地没有原版备份 ⇒ **绝不盲目继续**。
    // 原因：卸载/重装都要靠原版 index.html，没有它就没法保证还原得回去。
    // 但我们先尽力帮用户找回（常见于：主题是用别的工具/在别的目录装的）。
    console.error('\n❌ 检测到 WorkBuddy 里已经装着主题，但这个压缩包里没有原版备份。');
    console.error('   为了不把你的应用置于"卸不掉"的状态，安装器拒绝继续。\n');

    const found = searchOtherBackups(cur);
    if (found.length) {
      // 找到了匹配的备份 ⇒ 直接采用（复制到本包的 backup/），不用让用户手动搬。
      // 这正是"确定性验证"的价值：既然已经证明它就是这个版本的原版，就可以放心用。
      const ts = new Date().toISOString().replace(/[-:T]/g, '').slice(0, 14);
      const dest = path.join(BACKUP_DIR, `renderer-index.html.${ts}.bak`);
      fs.copyFileSync(found[0], dest);
      console.log('   ✅ 找到了与当前版本匹配的原版备份，已自动采用：');
      console.log('      ' + found[0]);
      console.log('      -> ' + dest);
      if (found.length > 1) {
        console.log(`      （另有 ${found.length - 1} 个同样匹配，已忽略）`);
      }
      origBak = dest;
    } else if (ARGS.adopt) {
      /**
       * --adopt：从当前已装内容**反推**一份"近似原版"当备份。
       *
       * ⚠⚠ 这不是无损操作，必须让用户知情 ⚠⚠
       *   反推 = 抹掉主题痕迹（去属性、去 link/script、去尾部补的空格）后补空格凑回原长。
       *   但**被注入时删掉的那段注释回不来了** —— 所以反推结果与官方原版**不逐字节相同**，
       *   只是长度一致、结构合法、能正常启动。
       *
       *   适用场景：当前装着主题、原版备份又彻底找不到了，但用户想换成本包这一版。
       *   代价：将来 --uninstall 还原的是这份"近似原版"，而不是官方原版。
       *   官方原版的差异仅在那段被删掉的中文注释（纯说明，不影响功能）。
       */
      console.log('\n⚠ --adopt：将从当前状态反推一份"近似原版"作为备份。');
      console.log('   注意：被注入时删掉的那段中文注释**无法恢复**，');
      console.log('         所以这份备份与官方原版不逐字节相同（长度一致、功能一致）。');
      console.log('   将来 --uninstall 会还原成这份"近似原版"，而不是官方原版。\n');

      const t = cur.toString('utf8');
      const skel = t
        .replace(/<link[^>]*href="file:\/\/\/[^"]*\/theme\.css"[^>]*>/g, '')
        .replace(/<script[^>]*src="file:\/\/\/[^"]*\/client\.js"[^>]*><\/script>/g, '')
        .replace(/(<html)\s+data-wb-flandre\b/g, '$1')
        .replace(/\s+$/, '');        // 去掉上次为凑长度补的空白
      // 补空格凑到与原长一致 —— 让它成为一个"长度合法"的 index.html，
      // 这样即使将来直接拿它去 --uninstall 也能正确写入（等长是硬要求）。
      const need = e.size - Buffer.byteLength(skel, 'utf8');
      if (need < 0) {
        console.error(`❌ 反推失败：抹掉主题痕迹后仍有 ${Buffer.byteLength(skel, 'utf8')} 字节 > ${e.size}，无法凑回原长。`);
        fs.closeSync(fd);
        closeExe();
        process.exit(1);
      }
      const skelPadded = skel + ' '.repeat(need);
      if (Buffer.byteLength(skelPadded, 'utf8') !== e.size) {
        console.error('❌ 反推失败：长度对不上。');
        fs.closeSync(fd);
        closeExe();
        process.exit(1);
      }
      const ts = new Date().toISOString().replace(/[-:T]/g, '').slice(0, 14);
      const dest = path.join(BACKUP_DIR, `renderer-index.html.${ts}.bak`);
      fs.writeFileSync(dest, Buffer.from(skelPadded, 'utf8'));
      origBak = dest;
      console.log('   ✅ 已反推并保存为备份：', dest);
      console.log(`      （骨架 ${Buffer.byteLength(skel, 'utf8')} 字节 + 补位 ${need} 字节 = ${e.size} 字节）`);
    } else {
      console.error('   ⚠ 在常见位置没找到与当前版本匹配的原版备份。\n');
      console.error('   说明这份 WorkBuddy 已经被装过主题，但原版 index.html 没有留存。');
      console.error('   安装器不会在"卸不掉"的状态下继续。可以选：');
      console.error('     a) 如果你还留着当初装主题的文件夹，把它的 backup\\ 目录拷到本包 backup\\ 下');
      console.error('        （需要 renderer-index.html.*.bak、asar-header.original.bin、orig.*.exe）');
      console.error('     b) 用当初那套工具先 --uninstall 还原，再回来装这一版');
      console.error('     c) 重装一次 WorkBuddy（最干净，但会丢本地配置）');
      console.error('     d) 若你确认能接受风险，用 --adopt 从当前状态反推一份"近似原版"再装');
      console.error('        （--adopt 会尽量还原，但无法保证与官方原版逐字节一致，谨慎使用）');
      fs.closeSync(fd);
      closeExe();
      process.exit(1);
    }
  }
  if (!origBak) {
    const ts = new Date()
      .toISOString()
      .replace(/[-:T]/g, '')
      .slice(0, 14);
    origBak = path.join(BACKUP_DIR, `renderer-index.html.${ts}.bak`);
    fs.writeFileSync(origBak, cur);
    console.log('\n首次安装：已自动备份原版 index.html ->', origBak);
  }
}
if (!fs.existsSync(HDR_BAK)) {
  fs.writeFileSync(HDR_BAK, hb);
  console.log('已备份原始 header ->', HDR_BAK);
}
if (!fs.existsSync(EXE_BAK)) {
  fs.copyFileSync(EXE, EXE_BAK);
  console.log('已备份原始 exe    ->', EXE_BAK);
}

// 决定目标内容
// ⚠ 注意 --reinstall 的语义是「先还原再装」，不是「还原」。
//    旧版脚本把 reinstall 和 uninstall 归在同一个分支里取 origBak 当 newContent，
//    结果 reinstall 写回去的是**原版内容** —— 表现就是"重装了一下，主题没了"。
//    离线端到端自测（_port_e2e.mjs）里这条断言正是为此加的。
let newContent;
if (mode === 'uninstall') {
  newContent = fs.readFileSync(origBak);
  if (newContent.length !== e.size) {
    console.error(`❌ 备份长度 ${newContent.length} 与 asar 记录 ${e.size} 不一致，拒绝写入。`);
    fs.closeSync(fd);
    process.exit(1);
  }
  console.log('原版备份  :', path.basename(origBak));

  // 三处一起还原
  const origHex = sha256(newContent);
  const hbNew = Buffer.from(hb);
  if (e.integrity.hash !== origHex) patchHeaderEntryHash(hbNew, e, e.integrity.hash, origHex);
  const newHeaderHash = sha256(hbNew);
  fs.writeSync(fd, newContent, 0, newContent.length, at);
  fs.writeSync(fd, hbNew, 0, hbNew.length, 16);
  fs.closeSync(fd);
  writeExeWithRetry(newHeaderHash);
  closeExe();
  console.log('\n✅ 已卸载，index.html 还原为原版，两层校验同步更新。');
  console.log('   主题文件仍留在 ' + SKIN_DIR + '，想彻底删掉可手动删该目录。');
  process.exit(0);
}

// install / reinstall 走同一条注入路径
{
  if (isSkinned && mode !== 'reinstall') {
    // 已装，但注入的 skin 路径可能指向**别的地方**（比如换了压缩包解压位置，
    // 或者从旧版本升级上来）。这时"无需重复安装"是错的 —— 主题会指向失效路径。
    const curSkin = (cur.toString('utf8').match(/file:\/\/\/([^"']+)\/theme\.css/) || [])[1];
    if (curSkin && curSkin.replace(/\//g, '\\').toLowerCase() !== SKIN_DIR.replace(/\//g, '\\').toLowerCase()) {
      console.log('\n⚠ 主题已装，但指向的目录与当前压缩包不同：');
      console.log('   已装指向 :', curSkin);
      console.log('   当前包内 :', SKIN_DIR);
      console.log('\n   ⇒ 请用 --reinstall 把注入路径改到当前压缩包（原主题会被替换）。');
      fs.closeSync(fd);
      process.exit(2);
    }
    console.log('\n已经是安装状态，无需重复安装。（想重新注入请用 --reinstall）');
    fs.closeSync(fd);
    process.exit(0);
  }
  if (!fs.existsSync(path.join(SKIN_DIR, 'theme.css'))) {
    console.error('❌ 找不到 ' + SKIN_DIR + '/theme.css —— 压缩包不完整，请重新解压。');
    fs.closeSync(fd);
    process.exit(1);
  }
  newContent = buildSkinned(fs.readFileSync(origBak, 'utf8'));
  console.log('原版备份  :', path.basename(origBak), mode === 'reinstall' ? '（重装：跳过"已装"判断）' : '');
}

// ── 三处同步写入 ──────────────────────────────────────────────────────────
// 写盘前先给"当前状态"拍快照：内容 + header + exe 里的期望哈希。
// 任何一步验证不过就用它整体回滚，绝不把应用留在起不来的状态。
const snapContent = Buffer.from(cur);
const snapHeader = Buffer.from(hb);
// exe 的快照按**真实字节区间**存（槽位前后各留一段），而不是按坐标存。
// 理由：坐标是算出来的，万一算错，按坐标回写就会"还原到错误的偏移"，
// 表面上报"已还原"，实际把 exe 改坏（这个坑真踩过）。存字节区间则与坐标无关，
// 原样盖回去必然是逐字节精确的。
const snapExeRanges = exeSlots.map((s) => {
  const from = Math.max(0, s.hexPos - 24);
  const to = Math.min(exeBuf0.length, s.hexPos + 88);
  return { from, buf: Buffer.from(exeBuf0.subarray(from, to)) };
});

function rollback(reason) {
  console.error('\n⚠ 校验未通过（' + reason + '），正在回滚到操作前状态…');
  try {
    const f1 = fs.openSync(ASAR, 'r+');
    fs.writeSync(f1, snapContent, 0, snapContent.length, at);
    fs.writeSync(f1, snapHeader, 0, snapHeader.length, 16);
    fs.closeSync(f1);
    console.error('   asar 已还原 ✅');
  } catch (err) {
    console.error('   asar 还原失败 ❌ ' + err.message);
    console.error('   请手动用 ' + HDR_BAK + ' 还原 header，或跑 --uninstall。');
  }
  try {
    // 优先复用一直握着的写句柄 —— 它必然能写（否则前面就报错了），
    // 比重新 open 一次稳得多（原来重新 open 会因 EBUSY 而"跳过还原"）。
    const own = fdExe === null ? null : fdExe;
    const f2 = own || fs.openSync(EXE, 'r+');
    for (const r of snapExeRanges) fs.writeSync(f2, r.buf, 0, r.buf.length, r.from);
    if (own) fs.fsyncSync(own);
    else fs.closeSync(f2);
    // 还原后必须**再验一次**：槽位数量与取值都要回到操作前
    const now = findExeHashSlots(fs.readFileSync(EXE));
    const same =
      now.length === exeSlots.length && now.every((s, i) => s.hex === exeSlots[i].hex);
    if (!same) {
      console.error('   exe  还原后校验不一致 ❌ —— 请用 ' + EXE_BAK + ' 覆盖还原。');
    } else {
      console.error('   exe  已还原并复验通过 ✅');
    }
  } catch (err) {
    // exe 被占用 ⇒ 说明这一步压根没写进去过，不是问题
    console.error('   exe  跳过（' + err.code + '）—— 开不了说明本次没改到它，属正常。');
  }
  console.error('✅ 已回滚 —— 应用应当仍可正常启动。若仍有疑虑，跑 --check 确认。');
  process.exit(1);
}

const newContentHex = sha256(newContent);

const hbNew = Buffer.from(hb);
if (e.integrity.hash !== newContentHex) {
  patchHeaderEntryHash(hbNew, e, e.integrity.hash, newContentHex);
}
if (hbNew.length !== hs) {
  console.error('❌ header 长度变了，中止。');
  fs.closeSync(fd);
  process.exit(1);
}

// 校验新 header 结构
const j2 = JSON.parse(hbNew.toString('utf8').replace(/\0+$/, ''));
const e2 = entryOf(j2, TARGET);
if (e2.integrity.hash !== newContentHex || e2.integrity.blocks[0] !== newContentHex) {
  console.error('❌ header 改写失败。');
  fs.closeSync(fd);
  process.exit(1);
}
if (e2.size !== e.size || e2.offset !== e.offset) {
  console.error('❌ 目标条目 size/offset 变了，中止。');
  fs.closeSync(fd);
  process.exit(1);
}

const newHeaderHash = sha256(hbNew);
console.log('\n一层：header entry 哈希 ->', newContentHex);
console.log('二层：新 header sha256  ->', newHeaderHash);

// 落盘 asar：先内容，再 header
if (dry) {
  console.log('\n🧪 --dry 试运行：已完成全部计算与前校验，**没有写入任何字节**。');
  console.log('   若要真正安装，去掉 --dry 重跑。');
  fs.closeSync(fd);
  closeExe();
  process.exit(0);
}
try {
  fs.writeSync(fd, newContent, 0, newContent.length, at);
  fs.writeSync(fd, hbNew, 0, hbNew.length, 16);
  fs.closeSync(fd);

  // 落盘 exe（复用一直握着的写句柄）
  const exeRes = writeExeWithRetry(newHeaderHash);
  closeExe();
  console.log(`二层：exe 期望值已更新（共 ${exeRes.count} 个槽位，改了 ${exeRes.changed} 个）`);
} catch (err) {
  try { fs.closeSync(fd); } catch { /* 已关闭 */ }
  // 注意：不要在这里 closeExe() —— rollback 会优先复用这个写句柄，
  // 而"重新 open 一次"恰恰是当前这种情况下最容易失败的动作。
  rollback('写入过程出错：' + err.message);
}

// ── 回读验证 ──────────────────────────────────────────────────────────────
const v = openAsar(false);
const vjson = JSON.parse(v.hb.toString('utf8').replace(/\0+$/, ''));
const ve = entryOf(vjson, TARGET);
const back = readAt(v.fd, v.dataStart + parseInt(ve.offset, 10), ve.size);
fs.closeSync(v.fd);

const backHex = sha256(back);
const backHeaderHash = sha256(v.hb);
const slots = exeExpectedHashes();

console.log('\n═══ 回读验证 ═══');
console.log('一层  内容哈希      :', backHex, backHex === ve.integrity.hash ? '✅' : '❌');
console.log('二层  header sha256 :', backHeaderHash);
console.log('      exe 期望值    :', slots.map((s) => s.hex).join(', '), slots.every((s) => s.hex === backHeaderHash) ? '✅' : '❌');
console.log('headerSize :', v.hs, v.hs === hs ? '(未变 ✅)' : '(变了 ❌)');
console.log('index.html size :', ve.size, ve.size === e.size ? '(未变 ✅)' : '(变了 ❌)');
console.log('主题标记   :', isSkinnedHtml(back.toString('utf8')) ? '在 ✅' : '不在');

const allOk =
  backHex === ve.integrity.hash &&
  slots.length === 2 &&
  slots.every((s) => s.hex === backHeaderHash) &&
  v.hs === hs &&
  ve.size === e.size;
if (!allOk) rollback('回读双层校验未对齐');
console.log('\n✅ 两层校验全部对齐 —— 可以启动应用了');

console.log('\n注入内容 :', INJECT);
console.log('html 标记:', `<html ${HTML_ATTR} …>`);
console.log('主题目录 :', SKIN_DIR);
console.log(`\n重启【${APP_NAME}】即可看到效果（主题只在 index.html，不用重装 asar 就能改配色）。`);
console.log(`（卸载：node tools/install.mjs --app-root="${APP.root}" --uninstall ）`);
