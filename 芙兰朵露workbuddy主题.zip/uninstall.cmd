@echo off
rem Console to UTF-8 so the Node output (Chinese) renders correctly.
rem This file itself is pure ASCII, so this cannot break cmd parsing.
chcp 65001 >nul 2>&1
setlocal enabledelayedexpansion
cd /d "%~dp0"

echo.
echo  ==============================================
echo   Flandre Theme  -  WorkBuddy Uninstaller
echo  ==============================================
echo.

set "NODE_BIN="
where node >nul 2>&1 && set "NODE_BIN=node"

if not defined NODE_BIN (
  for %%P in (
    "%ProgramFiles%\nodejs\node.exe"
    "%ProgramFiles(x86)%\nodejs\node.exe"
    "%LOCALAPPDATA%\Programs\nodejs\node.exe"
    "%APPDATA%\npm\node.exe"
  ) do (
    if not defined NODE_BIN if exist %%P set "NODE_BIN=%%~P"
  )
)

if not defined NODE_BIN (
  echo  [X] Node.js not found, cannot run the uninstaller.
  echo      Please install it from https://nodejs.org and try again.
  goto :hold
)

echo  This will restore WorkBuddy to its original official look.
echo.
choice /C YN /M "  Continue? [Y/N]"
if errorlevel 2 goto :hold

echo.
echo  ---- Step 1/2: make sure WorkBuddy is closed ----
echo.
call :closeapp WorkBuddy.exe
call :closeapp WorkBuddyAI.exe

echo.
echo  ---- Step 2/2: restore ----
echo.
"!NODE_BIN!" "tools\install.mjs" --uninstall --reap
if errorlevel 1 (
  echo.
  echo  [X] Uninstall FAILED.
  echo      Please send the output above to whoever gave you this theme.
  goto :hold
)

echo.
echo  ==============================================
echo   [OK] Restored to the official original.
echo        Theme assets remain in the skin\ folder;
echo        delete this whole folder to remove them fully.
echo  ==============================================
echo.
goto :hold

rem ---- helper: ask + force-close one process ------------------------------
:closeapp
tasklist /FI "IMAGENAME eq %1" 2>nul | find /I "%1" >nul
if errorlevel 1 goto :eof
echo  [!] %1 is running.
choice /C YN /M "      Force-close it and continue? [Y/N]"
if errorlevel 2 goto :eof
taskkill /F /T /IM %1 >nul 2>&1
timeout /t 5 /nobreak >nul
goto :eof

:hold
echo.
pause
endlocal
