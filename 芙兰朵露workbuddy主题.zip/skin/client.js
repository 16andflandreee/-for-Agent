/**
 * WorkBuddy · 芙兰朵露主题 · 注入脚本
 *
 * 干这些事：
 *   1. 给 <html> 打标记：
 *        data-wb-fl-ui        —— 常驻。设置面板 / 时钟浮层 的样式靠它作用域，
 *                                所以"关掉主题"时面板照样能用（否则会把面板样式一起关掉）。
 *        data-wb-fl-mode      —— 常驻。当前生效的明暗（dark / light）。auto 时跟随应用。
 *        data-wb-flandre      —— 只有"主题开启"时才挂。CSS 里 875 个令牌覆盖全靠它，
 *                                摘掉即完全恢复原生外观。
 *        data-wb-fl-chibi / -garland / -bg / -clock —— 各模块开关（"1"/"0"）。
 *      并用 MutationObserver 保住 —— WorkBuddy 的 ThemeManager / SkinManager
 *      会主动改写 html/body 的 class 与属性，标记被摘掉主题就整体失效。
 *      **只在缺失时写**，否则观察者会自激成死循环。
 *   2. 把 Q 版芙兰挂到聊天输入框左侧（探出半个身子），支持"敲脑袋"。
 *   3. 往设置弹窗里注入「芙兰朵露」导航项 + 面板（调主题 / 调插件）。
 *   4. 桌面时钟浮层（可选，可拖动）。
 *   5. 页面路由切换后重新挂载（SPA）。
 *
 * 所有 DOM 都带 wb-fl- 前缀，与 WorkBuddy 自己的类名不会撞。
 */
(function () {
  'use strict';
  if (window.__WB_FLANDRE__) return;
  window.__WB_FLANDRE__ = true;

  var ATTR = 'data-wb-flandre';
  var UI_ATTR = 'data-wb-fl-ui';
  var MODE_ATTR = 'data-wb-fl-mode';
  // 哪个主题（flandre / whale）。和 MODE_ATTR 正交：主题 × 明暗 = 4 套令牌。
  var THEME_ATTR = 'data-wb-fl-theme';
  var HIT_DURATION = 760;
  var STORE = 'wb-flandre:settings:v1';
  var STORE_POS = 'wb-flandre:clock-pos:v1';

  var DEFAULTS = {
    theme: 'flandre', // 'flandre' | 'none'  —— 想加新主题就往 THEMES 里加一条
    mode: 'dark', // dark | light | auto
    chibi: true,
    garland: true,
    bg: true,
    clock: false,
  };

  // 可选主题清单。加新主题 = 往这里加一条 + 补一份令牌表（见 说明.md §12.10）。
  //
  // `deco` 是**这套主题自己的装饰**（顺序 = 面板里"XX主题设置"段的行顺序）。
  //   ⚠ 装饰属于主题，插件属于应用 —— 所以水晶吊串/立绘/背景图都在这里，
  //     而桌面时钟在下面的「插件」段。别把两者混在一张表里。
  //   `key` 是**槽位名**，两套主题共用同一批槽位（立绘槽 / 顶部装饰槽 / 底图槽），
  //     所以开关状态是共享的：你关掉"立绘槽"，换主题后那个槽位也还是关的。
  //     这样语义是"这个位置要不要装饰"，而不是"某个具体素材的开关"。
  // `accent` / `accent2` 只用来画主题卡片上那个小圆点，不影响实际配色。
  var THEMES = [
    {
      id: 'flandre',
      name: '芙兰朵露 · 哥特',
      desc: '暗红金 · 结晶吊串 · 右侧立绘',
      hero: ['芙兰朵露 · 哥特主题', '暗夜与白昼两套配色，可跟随应用的深浅色自动切换'],
      decoTitle: '芙兰朵露主题设置',
      accent: '#c81e3c',
      accent2: '#e8556e',
      deco: [
        { key: 'chibi', label: 'Q 版芙兰立绘', hint: '输入框左侧的 Q 版芙兰，戳一下会有反应' },
        { key: 'garland', label: '顶部水晶吊串', hint: '窗口栏上的水晶挂饰' },
        { key: 'bg', label: '氛围底图', hint: '绯红雾气底色 + 右侧的芙兰立绘' },
      ],
    },
    {
      id: 'whale',
      name: '爱思考的大肥鱼',
      desc: '深海蓝白 · 上升气泡 · 圆形头像',
      hero: ['爱思考的大肥鱼', '轻松明亮的深海配色，背景就是那张大肥鱼'],
      decoTitle: '爱思考的大肥鱼主题设置',
      accent: '#2e7be0',
      accent2: '#4fc3e8',
      deco: [
        { key: 'chibi', label: '大肥鱼头像', hint: '输入框左侧的圆形头像，戳一下会有反应' },
        { key: 'garland', label: '上升气泡', hint: '从水下往上冒的小气泡' },
        { key: 'bg', label: '深海背景图', hint: '浅海渐变底色 + 右侧的「爱思考的大肥鱼」' },
      ],
    },
    {
      id: 'none',
      name: '原生外观',
      desc: '不使用任何主题，完全恢复 WorkBuddy 默认',
      accent: '#8a8f98',
      accent2: '#b8bcc4',
      deco: [],
    },
  ];

  var state = load();

  function load() {
    var o = {};
    for (var k in DEFAULTS) if (Object.prototype.hasOwnProperty.call(DEFAULTS, k)) o[k] = DEFAULTS[k];
    try {
      var raw = localStorage.getItem(STORE);
      if (raw) {
        var j = JSON.parse(raw);
        for (var k2 in o) {
          if (j && typeof j[k2] !== 'undefined' && j[k2] !== null) o[k2] = j[k2];
        }
        // 旧版存的是布尔 enabled（一个"启用/停用"开关），迁移成 theme 字符串
        if (j && typeof j.enabled === 'boolean' && typeof j.theme === 'undefined') {
          o.theme = j.enabled ? 'flandre' : 'none';
        }
      }
    } catch (e) {
      /* 隐私模式 / 存储被禁：用默认值，不报错 */
    }
    if (['dark', 'light', 'auto'].indexOf(o.mode) < 0) o.mode = 'dark';
    if (!THEMES.some(function (t) { return t.id === o.theme; })) o.theme = 'flandre';
    return o;
  }

  // 主题是否生效（唯一判据，别再散落成布尔字段，会跟 theme 脱钩）
  function themeOn() {
    return state.theme !== 'none';
  }

  // 当前主题的清单条目（含它自己的装饰定义）。'none' 也返回一个空壳，
  // 免得调用处到处判空。
  function activeTheme() {
    for (var i = 0; i < THEMES.length; i++) if (THEMES[i].id === state.theme) return THEMES[i];
    return { id: 'none', name: '原生外观', deco: [] };
  }

  function save() {
    try {
      localStorage.setItem(STORE, JSON.stringify(state));
    } catch (e) {}
  }

  /* ─────────────────────── 1. 模式解析（跟随应用深浅色） ─────────────────────── */
  /* WorkBuddy 的明暗信号有好几套并存（实测）：
       浅色基线   : body[data-vscode-theme-name="IDE Light"]
       深色覆盖   : [data-theme=dark] / html.cb-dark / body.vscode-dark / body.dark / .dark
       聊天组件层 : .cr-theme[data-cr-theme=dark|light]
     逐条判，拿不到就退回"深色"（WorkBuddy 默认外观偏深，且主题默认就是暗夜版）。 */
  function appMode() {
    var b = document.body;
    var h = document.documentElement;
    var name = (b && b.getAttribute('data-vscode-theme-name')) || '';
    if (/night|dark/i.test(name)) return 'dark';
    if (/light/i.test(name)) return 'light';

    var cr = document.querySelector('.cr-theme');
    if (cr) {
      var v = cr.getAttribute('data-cr-theme');
      if (v === 'light') return 'light';
      if (v === 'dark') return 'dark';
    }
    if (h.getAttribute('data-theme') === 'dark') return 'dark';
    if (b && b.getAttribute('data-theme') === 'dark') return 'dark';
    var cls = (h.className || '') + ' ' + ((b && b.className) || '');
    if (/\b(cb-dark|vscode-dark|dark)\b/.test(cls)) return 'dark';
    if (/\b(cb-light|vscode-light|light)\b/.test(cls)) return 'light';
    return 'dark';
  }

  function effectiveMode() {
    return state.mode === 'auto' ? appMode() : state.mode;
  }

  /* ───────────────────────────── 2. 属性落地 ───────────────────────────── */
  var root = document.documentElement;

  function setAttr(el, k, v) {
    if (el.getAttribute(k) !== v) el.setAttribute(k, v);
  }

  function apply() {
    setAttr(root, UI_ATTR, '1');
    setAttr(root, MODE_ATTR, effectiveMode());
    // 主题属性无条件写：CSS 里鲸鱼块靠 [data-wb-fl-theme=whale] 命中，
    // 芙兰块靠 :not([data-wb-fl-theme=whale]) 命中 —— 两个都要能判，
    // 所以哪怕选的是 'none' 也照样写上（此时 data-wb-flandre 已摘除，不影响）。
    setAttr(root, THEME_ATTR, state.theme);

    if (themeOn()) {
      if (!root.hasAttribute(ATTR)) root.setAttribute(ATTR, '1');
    } else if (root.hasAttribute(ATTR)) {
      root.removeAttribute(ATTR);
    }

    setAttr(root, 'data-wb-fl-chibi', state.chibi ? '1' : '0');
    setAttr(root, 'data-wb-fl-garland', state.garland ? '1' : '0');
    setAttr(root, 'data-wb-fl-bg', state.bg ? '1' : '0');
    setAttr(root, 'data-wb-fl-clock', state.clock ? '1' : '0');

    syncModules();
  }

  // WorkBuddy 切换主题 / 应用皮肤时会重写 html 上的 class 与属性，
  // 只在"标记丢了"时补回来；补回后观察者不再触发（属性已存在）。
  // ⚠ 关掉主题时不能再补 —— 否则开关会被自己顶回去。
  new MutationObserver(function () {
    if (themeOn()) {
      if (!root.hasAttribute(ATTR)) root.setAttribute(ATTR, '1');
    }
    if (!root.hasAttribute(UI_ATTR)) root.setAttribute(UI_ATTR, '1');
  }).observe(root, { attributes: true, attributeFilter: [ATTR, UI_ATTR] });

  // 跟随应用：应用换了深浅色就把 data-wb-fl-mode 同步过去
  var themeObs = new MutationObserver(function () {
    if (state.mode !== 'auto') return;
    setAttr(root, MODE_ATTR, effectiveMode());
  });
  themeObs.observe(root, { attributes: true, attributeFilter: ['class', 'data-theme'] });
  function watchBody() {
    if (!document.body) return;
    themeObs.observe(document.body, {
      attributes: true,
      attributeFilter: ['class', 'data-theme', 'data-vscode-theme-name'],
    });
  }

  /* ─────────────────────────── 3. Q 版立绘 ─────────────────────────────── */
  /* 锚点：优先用实测确认的输入卡片 `.cr-input-container`
     （从 app.asar 的 lib-chat-ui 样式里挖出来的 —— 聊天界面里唯一
     position:relative 的输入容器，原样式 border-radius:24px）。
     后面几个是其它页面的候选；全都不中时走几何兜底：
     找页面上最大的 Slate 编辑器，向上找到"有圆角的卡片"祖先。 */
  var HOST_SELECTORS = [
    '.cr-input-container',
    '[class*="home-composer"] [class*="input-slot"]',
    '[class*="chat-input"] [class*="content"]',
    '[class*="composer"] [class*="card"]',
  ];

  function usable(el, minW, minH) {
    if (!el) return false;
    var r = el.getBoundingClientRect();
    return r.width > minW && r.height > minH;
  }

  // 兜底：不依赖类名，纯按几何特征找"输入卡片"
  function findByGeometry() {
    var eds = [].slice.call(
      document.querySelectorAll('[data-slate-editor], textarea, [contenteditable="true"]')
    );
    var best = null;
    var bestArea = 0;
    eds.forEach(function (el) {
      var r = el.getBoundingClientRect();
      if (r.width < 200 || r.height < 18) return;
      var a = r.width * r.height;
      if (a > bestArea) {
        bestArea = a;
        best = el;
      }
    });
    if (!best) return null;
    var p = best;
    for (var i = 0; i < 8 && p && p !== document.body; i++) {
      var s = getComputedStyle(p);
      if (parseFloat(s.borderRadius) >= 5 && (s.boxShadow !== 'none' || parseFloat(s.borderTopWidth) > 0)) {
        return p;
      }
      p = p.parentElement;
    }
    return best.parentElement;
  }

  function findHost() {
    for (var i = 0; i < HOST_SELECTORS.length; i++) {
      var list = document.querySelectorAll(HOST_SELECTORS[i]);
      for (var j = list.length - 1; j >= 0; j--) {
        if (usable(list[j], 220, 60)) return list[j];
      }
    }
    return findByGeometry();
  }

  var node = null;
  var host = null;

  function buildChibi() {
    var wrap = document.createElement('div');
    wrap.className = 'wb-fl-chibi';
    wrap.setAttribute('data-state', 'idle');

    var inner = document.createElement('div');
    inner.className = 'wb-fl-chibi-inner';

    var glow = document.createElement('div');
    glow.className = 'wb-fl-chibi-glow';

    var art = document.createElement('div');
    art.className = 'wb-fl-chibi-art';
    ['idle', 'pain', 'cry'].forEach(function (f) {
      var l = document.createElement('div');
      l.className = 'wb-fl-chibi-layer';
      l.setAttribute('data-face', f);
      art.appendChild(l);
    });

    var fx = document.createElement('div');
    fx.className = 'wb-fl-chibi-fx';

    var hit = document.createElement('div');
    hit.className = 'wb-fl-chibi-hit';
    hit.setAttribute('title', '戳一下' + (state.theme === 'whale' ? '鲸鱼娘' : '芙兰'));

    inner.appendChild(glow);
    inner.appendChild(art);
    inner.appendChild(fx);
    wrap.appendChild(inner);
    wrap.appendChild(hit);

    hit.addEventListener('pointerdown', function (e) {
      // 保住输入框焦点：点装饰不该把光标踢出去，也不该让事件冒到 React 的根监听
      e.preventDefault();
      e.stopPropagation();
      knock(fx, e.clientX - wrap.getBoundingClientRect().left, e.clientY - wrap.getBoundingClientRect().top);
    });
    ['click', 'dblclick', 'mousedown', 'mouseup', 'contextmenu'].forEach(function (t) {
      hit.addEventListener(t, function (e) {
        e.preventDefault();
        e.stopPropagation();
      });
    });

    return wrap;
  }

  var PARTICLE_COLORS = ['#E3C05B', '#E8556E', '#F7E4AE', '#C81E3C', '#F0D27C'];
  // 鲸鱼主题：水光青蓝（同明度档位，换的只是色相）
  var PARTICLE_COLORS_WHALE = ['#8FE9F5', '#4FC3E8', '#CFF3FF', '#2E7BE0', '#A8E8F5'];

  function knock(fx, x, y) {
    if (!node) return;
    // 表情：鲸鱼主题的两张差分是「哭哭（idle 层）/ 被敲（pain 层）」，
    // 用户要的是"点了就变被敲"→ 固定走 pain；
    // 芙兰那边保持原来的"痛 ＞＜ 与 哭 随机"，读起来像"每次戳反应不太一样"。
    var state2 = state.theme === 'whale' ? 'pain' : Math.random() < 0.5 ? 'pain' : 'cry';
    node.setAttribute('data-state', state2);
    setTimeout(function () {
      if (node) node.setAttribute('data-state', 'idle');
    }, HIT_DURATION);

    burst(fx, x, y);
  }

  function burst(fx, x, y) {
    // 粒子配色按主题走：芙兰是金红，鲸鱼是水光青
    // （金红粒子撒在浅海蓝里很跳，用户要求"别太违和"）
    var palette = state.theme === 'whale' ? PARTICLE_COLORS_WHALE : PARTICLE_COLORS;
    // 冲击闪光 + 冲击环：留在敲中的那一点原地扩散，给"被敲"一个受力点
    ['flash', 'ring'].forEach(function (kind) {
      var w = document.createElement('div');
      w.className = 'wb-fl-chibi-wave';
      w.setAttribute('data-kind', kind);
      w.style.left = x + 'px';
      w.style.top = y + 'px';
      var size = kind === 'flash' ? 46 : 30;
      w.style.width = size + 'px';
      w.style.height = size + 'px';
      fx.appendChild(w);
      setTimeout(function () {
        w.remove();
      }, 520);
    });

    // 粒子：四角星（通用）+ 六边形结晶（她翅膀上就是结晶）
    var n = 11;
    for (var i = 0; i < n; i++) {
      var p = document.createElement('div');
      p.className = 'wb-fl-chibi-p';
      p.setAttribute('data-shape', i % 3 === 0 ? 'crystal' : 'star');
      var ang = (Math.PI * 2 * i) / n + Math.random() * 0.5;
      var dist = 34 + Math.random() * 52;
      var size = 6 + Math.random() * 8;
      p.style.left = x + 'px';
      p.style.top = y + 'px';
      p.style.color = PARTICLE_COLORS[i % PARTICLE_COLORS.length];
      p.style.setProperty('--dx', Math.cos(ang) * dist + 'px');
      p.style.setProperty('--dy', Math.sin(ang) * dist - 14 + 'px');
      p.style.setProperty('--sz', size + 'px');
      p.style.setProperty('--sc', (0.4 + Math.random() * 0.6).toFixed(2));
      p.style.setProperty('--rot', Math.round(Math.random() * 360 - 180) + 'deg');
      p.style.setProperty('--dur', Math.round(520 + Math.random() * 260) + 'ms');
      p.style.setProperty('--delay', Math.round(Math.random() * 60) + 'ms');
      fx.appendChild(p);
      (function (el) {
        setTimeout(function () {
          el.remove();
        }, 1000);
      })(p);
    }
  }

  /* 立绘尺寸与坐标：用 fixed 定位，坐标按输入卡片的 rect 现算。
     空间不够时等比缩小；实在放不下就淡出 —— 总之不会出现"被裁成一半"。 */
  var CHIBI_W = 140; // 芙兰：满尺寸宽（高 = 宽 × 195/140，竖构图）
  var CHIBI_H = 195;
  // 鲸鱼主题的立绘是近方形（1100×1031）。同一个 140 宽会显得比芙兰小一截
  // （芙兰 140×195 是竖构图，"脸"的绝对尺寸大得多）—— 实测把方形立绘也做成 140 宽时，
  // 脸的尺寸只剩原来那个圆形头像的一半，看着就"小气"。所以给它单独一个更大的上限。
  var WHALE_W = 176;
  var WHALE_RATIO = 0.9375; // 素材高/宽 = 1031/1100
  var CHIBI_MIN = 58; // 再小就不显示了
  var CHIBI_GAP = 6; // 与卡片左/下边缘的呼吸间距

  // 尺寸策略按主题分叉，只在这里算一次；CSS 侧直接吃 --fl-chibi-w / --fl-chibi-h。
  function chibiSize(avail) {
    var isWhale = state.theme === 'whale';
    var w = Math.min(isWhale ? WHALE_W : CHIBI_W, avail);
    var h = isWhale ? w * WHALE_RATIO : (w * CHIBI_H) / CHIBI_W;
    return { w: w, h: Math.round(h) };
  }

  function place() {
    if (!node || !host || !host.isConnected) return;
    var r = host.getBoundingClientRect();
    if (!r.width || !r.height) return;

    // 卡片左边缘到视口左边还剩多少空间 —— 首页输入框居中时很宽裕，
    // 窄窗口 / 侧栏展开时可能不够，那就缩小。
    var avail = r.left - CHIBI_GAP;
    var sz = chibiSize(avail);
    var w = sz.w;
    if (w < CHIBI_MIN) {
      if (node.style.opacity !== '0') node.style.opacity = '0';
      return;
    }
    if (node.style.opacity === '0') node.style.opacity = '';

    var h = sz.h;
    node.style.setProperty('--fl-chibi-w', w + 'px');
    node.style.setProperty('--fl-chibi-h', h + 'px');
    node.style.setProperty('--fl-chibi-x', Math.round(r.left - w + 1) + 'px');
    node.style.setProperty('--fl-chibi-y', Math.round(r.bottom + CHIBI_GAP - h) + 'px');
  }

  function attach() {
    if (!node) node = buildChibi();
    // 挂到 <body> 而不是输入卡片内部：
    // ① 立绘是 fixed 定位，落在有 transform / filter / will-change 的祖先里会
    //    退化成"相对该祖先定位"，body 最干净；
    // ② 输入卡片外面还套着 .wb-home-composer__input-slot 等容器，其中任意一层
    //    带 overflow:hidden/auto 都会把伸出去的立绘裁掉（"只显示一半"的根因）。
    if (node.parentNode !== document.body) {
      document.body.appendChild(node);
      root.setAttribute('data-wb-fl-chibi-mounted', '1');
    }
  }

  function mountChibi() {
    if (!document.body) return;
    if (!themeOn() || !state.chibi) return;
    // host 还活着：只更新坐标（流式输出时每帧都会跑到这里，省掉重复查询）
    if (host && host.isConnected) {
      attach();
      place();
      return;
    }

    var h = findHost();
    if (!h) return;
    host = h;
    attach();
    place();
  }

  function unmountChibi() {
    if (node && node.parentNode) node.parentNode.removeChild(node);
    host = null;
  }

  /* ───────────────────────── 4. 桌面时钟浮层 ───────────────────────────── */
  var clockNode = null;
  var clockHM = null;
  var clockSec = null;
  var clockDate = null;
  var clockTimer = null;
  var WEEK = ['周日', '周一', '周二', '周三', '周四', '周五', '周六'];

  function pad2(n) {
    return n < 10 ? '0' + n : '' + n;
  }

  function clockTick() {
    if (!clockNode) return;
    var now = new Date();
    clockHM.textContent = pad2(now.getHours()) + ':' + pad2(now.getMinutes());
    clockSec.textContent = pad2(now.getSeconds());
    clockDate.textContent = WEEK[now.getDay()] + ' · ' + (now.getMonth() + 1) + '月' + now.getDate() + '日';
  }

  function buildClock() {
    var n = document.createElement('div');
    n.className = 'wb-fl-clock';
    n.setAttribute('data-min', '0');
    n.setAttribute('title', '拖动移动 · 双击收起');

    var t = document.createElement('div');
    t.className = 'wb-fl-clock__time';
    clockHM = document.createElement('span');
    clockSec = document.createElement('span');
    clockSec.className = 'wb-fl-clock__sec';
    t.appendChild(clockHM);
    t.appendChild(clockSec);

    clockDate = document.createElement('div');
    clockDate.className = 'wb-fl-clock__date';

    n.appendChild(t);
    n.appendChild(clockDate);

    // 恢复上次拖到的位置
    try {
      var p = JSON.parse(localStorage.getItem(STORE_POS) || 'null');
      if (p && typeof p.x === 'number' && typeof p.y === 'number') {
        n.style.setProperty('--fl-clock-x', p.x + 'px');
        n.style.setProperty('--fl-clock-y', p.y + 'px');
        n.style.setProperty('--fl-clock-r', 'auto');
        n.style.setProperty('--fl-clock-b', 'auto');
      }
      if (p && p.min) n.setAttribute('data-min', '1');
    } catch (e) {}

    // 拖动：pointerdown 时记下抓取点，move 时把 left/top 写进 CSS 变量。
    // 只改 --fl-clock-x/y 并同时把 right/bottom 置 auto —— 否则 left 与 right
    // 同时有效，宽度会从两端被撑开（元素没有固定 width）。
    n.addEventListener('pointerdown', function (e) {
      if (e.button !== 0) return;
      e.preventDefault();
      e.stopPropagation();
      var r = n.getBoundingClientRect();
      var ox = e.clientX - r.left;
      var oy = e.clientY - r.top;
      var moved = false;
      var last = { x: Math.round(r.left), y: Math.round(r.top) };
      n.setAttribute('data-dragging', '1');

      function move(ev) {
        moved = true;
        var x = Math.max(4, Math.min(window.innerWidth - r.width - 4, ev.clientX - ox));
        var y = Math.max(4, Math.min(window.innerHeight - r.height - 4, ev.clientY - oy));
        last = { x: Math.round(x), y: Math.round(y) };
        n.style.setProperty('--fl-clock-x', last.x + 'px');
        n.style.setProperty('--fl-clock-y', last.y + 'px');
        n.style.setProperty('--fl-clock-r', 'auto');
        n.style.setProperty('--fl-clock-b', 'auto');
      }
      function up() {
        n.removeAttribute('data-dragging');
        window.removeEventListener('pointermove', move);
        window.removeEventListener('pointerup', up);
        if (moved) {
          try {
            localStorage.setItem(STORE_POS, JSON.stringify({ x: last.x, y: last.y, min: n.getAttribute('data-min') === '1' }));
          } catch (e2) {}
        }
      }
      window.addEventListener('pointermove', move);
      window.addEventListener('pointerup', up);
    });

    n.addEventListener('dblclick', function (e) {
      e.preventDefault();
      e.stopPropagation();
      var min = n.getAttribute('data-min') === '1';
      n.setAttribute('data-min', min ? '0' : '1');
      try {
        var p = JSON.parse(localStorage.getItem(STORE_POS) || 'null') || {};
        p.min = !min;
        localStorage.setItem(STORE_POS, JSON.stringify(p));
      } catch (e2) {}
    });
    ['click', 'mousedown', 'mouseup', 'contextmenu'].forEach(function (t2) {
      n.addEventListener(t2, function (e) {
        e.stopPropagation();
      });
    });

    return n;
  }

  function mountClock() {
    if (!document.body) return;
    if (!state.clock) return;
    if (!clockNode) {
      clockNode = buildClock();
      clockTick();
    }
    if (clockNode.parentNode !== document.body) document.body.appendChild(clockNode);
    if (!clockTimer) clockTimer = setInterval(clockTick, 1000);
  }

  function unmountClock() {
    if (clockTimer) {
      clearInterval(clockTimer);
      clockTimer = null;
    }
    if (clockNode && clockNode.parentNode) clockNode.parentNode.removeChild(clockNode);
  }

  /* ── 上升气泡：JS 逐个生成（替代原来的 CSS 平铺网格）────────────────────
     为什么 DOM 化 —— 旧做法是 `html::after` 上一个伪元素，用 6 层
     radial-gradient 平铺 + 一条关键帧平移 background-position。它的"生硬"
     不是参数问题，是机制决定的：
       ① 平铺 ⇒ 同一层里所有气泡**尺寸相同、横向间距相同**；
       ② 6 层共用一条 19s 关键帧 ⇒ **周期、相位、方向全一致**，永远同步上升。
     合起来就是一片整齐的网格。用户原话："气泡的生成太生硬了"。
     现在每个气泡一个 DOM 元素，尺寸/位置/时长/相位/飘移各自随机 ⇒
     任意两个周期都不同，永远不会重新对齐成网格。

     样式在 theme-whale.css §4（.wb-fl-bubble-layer / .wb-fl-bubble / keyframes）。 */

  // 旋钮：份数。想更热闹就加大；想清爽就减到 16 左右。
  var BUBBLE_COUNT = 28;
  var bubbleLayer = null;

  function rnd(a, b) {
    return a + Math.random() * (b - a);
  }

  function buildBubbles() {
    var layer = document.createElement('div');
    layer.className = 'wb-fl-bubble-layer';
    layer.setAttribute('aria-hidden', 'true');
    for (var i = 0; i < BUBBLE_COUNT; i++) {
      var b = document.createElement('div');
      b.className = 'wb-fl-bubble';
      var size = rnd(4, 22); // 直径
      var dur = rnd(11, 26); // 上升时长（s），越短升得越快
      var delay = -rnd(0, dur); // 负延迟 = 从半途开始 ⇒ 首屏就有分布，不会"一起从底下冒出来"
      var drift = rnd(-34, 34); // 横向飘移幅度
      // 小气泡更淡：读起来像"更远"，也避免一堆小点在眼前乱跳
      var peak = 0.34 + (size / 22) * 0.51;
      b.style.setProperty('--bub-s', size.toFixed(1) + 'px');
      b.style.setProperty('--bub-x', rnd(0, 100).toFixed(2) + '%');
      b.style.setProperty('--bub-d', dur.toFixed(2) + 's');
      b.style.setProperty('--bub-delay', delay.toFixed(2) + 's');
      b.style.setProperty('--bub-dx', drift.toFixed(1) + 'px');
      b.style.setProperty('--bub-o', peak.toFixed(2));
      b.style.setProperty('--bub-hx', rnd(22, 44).toFixed(1) + '%');
      b.style.setProperty('--bub-hy', rnd(22, 44).toFixed(1) + '%');
      layer.appendChild(b);
    }
    return layer;
  }

  function mountBubbles() {
    if (!document.body) return;
    if (!bubbleLayer) bubbleLayer = buildBubbles();
    if (bubbleLayer.parentNode !== document.body) document.body.appendChild(bubbleLayer);
  }

  function unmountBubbles() {
    if (bubbleLayer && bubbleLayer.parentNode) bubbleLayer.parentNode.removeChild(bubbleLayer);
  }

  function syncModules() {
    if (!document.body) return;
    if (themeOn() && state.chibi) mountChibi();
    else unmountChibi();
    // ⚠ 时钟也必须跟着 themeOn() —— 它的隐藏规则挂在 html[data-wb-flandre] 上，
    //   主题一关那条规则就不生效了，只靠 CSS 兜不住，必须在 JS 侧卸载。
    if (themeOn() && state.clock) mountClock();
    else unmountClock();
    // 气泡是**鲸鱼主题独有**的装饰 —— 芙兰那边同一个装饰槽位是 CSS 水晶吊串，
    // 所以这里必须再判一次 theme === 'whale'，否则在芙兰主题下会多挂一层空 DOM。
    // ⚠ 同样要跟 themeOn()：CSS 兜底挂在 html[data-wb-flandre] 上，主题一关就失效。
    if (themeOn() && state.theme === 'whale' && state.garland) mountBubbles();
    else unmountBubbles();
  }

  /* ────────────────────── 5. 设置面板「芙兰朵露」 ──────────────────────── */
  /* 注入思路（实测 DOM）：
       .settings-modal
         .settings-modal__nav      → nav.settings-navigation > 若干 group
         .settings-modal__content  → .settings-modal__header + .settings-modal__panel
     导航项：追加到**第一个 group**（"通用"）末尾，位置与「外观」同组，最自然。
     面板  ：作为 .settings-modal__panel 的兄弟插到 content 末尾；打开时把原生
             面板 display:none。这样顶部的标题栏、关闭按钮、Esc 全部沿用原生，
             不会出现"外挂了一个弹窗"的割裂感。
     React 只重排它自己 fiber 树里的节点，我们追加的额外节点会被保留；
     万一被重排掉，body 的 MutationObserver 会补回来。 */

  var panelNode = null;
  var panelActive = false;
  var uid = 0;

  function mk(tag, cls, text) {
    var n = document.createElement(tag);
    if (cls) n.className = cls;
    if (text != null) n.textContent = text;
    return n;
  }

  var NAV_ICON =
    '<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" ' +
    'stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round">' +
    '<path d="M12 2.6 6.2 8.4 12 21.4 17.8 8.4z"></path>' +
    '<path d="M6.2 8.4h11.6M12 2.6v18.8M9.1 8.4 12 21.4l2.9-13"></path></svg>';

  function makeSwitch(on, onChange) {
    uid += 1;
    var id = 'wb-fl-sw-' + uid;
    var label = mk('label', 'wb-switch wb-switch--medium settings-v2-switch');
    label.setAttribute('for', id);
    var ctrl = mk('span', 'wb-switch__control');
    var input = document.createElement('input');
    input.type = 'checkbox';
    input.id = id;
    input.className = 'wb-switch__input';
    input.setAttribute('role', 'switch');
    input.checked = !!on;
    var track = mk('span', 'wb-switch__track');
    track.setAttribute('aria-hidden', 'true');
    track.appendChild(mk('span', 'wb-switch__thumb'));
    ctrl.appendChild(input);
    ctrl.appendChild(track);
    label.appendChild(ctrl);
    input.addEventListener('change', function () {
      onChange(input.checked);
    });
    // 阻止冒泡到设置弹窗的 overlay（点 overlay 会关掉整个设置）
    label.addEventListener('click', function (e) {
      e.stopPropagation();
    });
    return { node: label, input: input };
  }

  function makeSeg(options, value, onPick) {
    var wrap = mk('div', 'wb-fl-seg');
    options.forEach(function (o) {
      var b = mk('button', 'wb-fl-seg__btn', o.label);
      b.type = 'button';
      b.setAttribute('data-v', o.v);
      b.setAttribute('data-on', o.v === value ? '1' : '0');
      b.addEventListener('click', function (e) {
        e.preventDefault();
        e.stopPropagation();
        onPick(o.v);
      });
      wrap.appendChild(b);
    });
    return { node: wrap, sync: function (v) {
      [].forEach.call(wrap.children, function (b) {
        b.setAttribute('data-on', b.getAttribute('data-v') === v ? '1' : '0');
      });
    } };
  }

  function makeRow(title, desc, action) {
    var row = mk('div', 'wb-fl-row');
    var main = mk('div', 'wb-fl-row__main');
    main.appendChild(mk('div', 'wb-fl-row__title', title));
    if (desc) main.appendChild(mk('div', 'wb-fl-row__desc', desc));
    var act = mk('div', 'wb-fl-row__action');
    act.appendChild(action);
    row.appendChild(main);
    row.appendChild(act);
    return row;
  }

  function makeGroup(label, rows) {
    var g = mk('div', 'general-settings-panel__group');
    g.appendChild(mk('p', 'general-settings-panel__group-label', label));
    var card = mk('div', 'general-settings-panel__group-card');
    rows.forEach(function (r) {
      card.appendChild(r);
    });
    g.appendChild(card);
    return g;
  }

  // 主题选择卡片：一行一个主题（圆点 + 名称 + 说明）。原生没有这种控件，自绘。
  function makeThemeCard(t, onPick) {
    var card = mk('button', 'wb-fl-theme-card');
    card.type = 'button';
    card.setAttribute('data-v', t.id);
    card.setAttribute('role', 'radio');
    // 色点用**这张卡自己的主题色**（theme.css 里的 fallback 是芙兰的绯红），
    // 这样一眼能看出每个主题是什么颜色，而不是都长一样。
    if (t.accent) card.style.setProperty('--fl-card-accent', t.accent);
    if (t.accent2) card.style.setProperty('--fl-card-accent2', t.accent2);
    if (t.accent) card.style.setProperty('--fl-card-tint', hexA(t.accent, 0.09));
    if (t.accent) card.style.setProperty('--fl-card-tint-strong', hexA(t.accent, 0.14));
    card.appendChild(mk('span', 'wb-fl-theme-card__dot'));
    var main = mk('span', 'wb-fl-theme-card__main');
    main.appendChild(mk('span', 'wb-fl-theme-card__name', t.name));
    main.appendChild(mk('span', 'wb-fl-theme-card__desc', t.desc));
    card.appendChild(main);
    card.addEventListener('click', function (e) {
      e.preventDefault();
      e.stopPropagation();
      onPick(t.id);
    });
    return {
      node: card,
      sync: function (id) {
        var on = t.id === id;
        card.setAttribute('data-on', on ? '1' : '0');
        card.setAttribute('aria-checked', on ? 'true' : 'false');
      },
    };
  }

  // 装饰段标题：优先用主题自己写的 decoTitle，没写才退回"<名字>主题设置"
  function decoTitleOf(t) {
    return t.decoTitle || t.name + '主题设置';
  }

  function hexA(hex, a) {
    var n = parseInt(String(hex).replace('#', ''), 16);
    return 'rgba(' + ((n >> 16) & 255) + ', ' + ((n >> 8) & 255) + ', ' + (n & 255) + ', ' + a + ')';
  }

  // 装饰行：文案会随主题变，所以把两个文本节点留着，切主题时原地改字。
  function makeDecoRow(item, action) {
    var row = mk('div', 'wb-fl-row');
    var main = mk('div', 'wb-fl-row__main');
    var title = mk('div', 'wb-fl-row__title', item.label);
    var desc = mk('div', 'wb-fl-row__desc', item.hint);
    main.appendChild(title);
    main.appendChild(desc);
    var act = mk('div', 'wb-fl-row__action');
    act.appendChild(action);
    row.appendChild(main);
    row.appendChild(act);
    return {
      node: row,
      set: function (it) {
        title.textContent = it.label;
        desc.textContent = it.hint;
      },
    };
  }

  function buildPanel() {
    var panel = mk('div', 'wb-fl-panel');
    panel.setAttribute('data-wb-fl-panel', '1');
    panel.style.display = 'none';

    var scroll = mk('div', 'wb-fl-panel__scroll');
    var wrap = mk('div', 'general-settings-panel');

    var refs = {};

    // —— 头图（文案跟着当前主题变）——
    var cur = activeTheme();
    var hero = mk('div', 'wb-fl-panel__hero');
    hero.appendChild(mk('div', 'wb-fl-panel__hero-art'));
    var heroText = mk('div');
    var heroTitle = mk('p', 'wb-fl-panel__hero-title', cur.hero ? cur.hero[0] : cur.name);
    var heroSub = mk('p', 'wb-fl-panel__hero-sub', cur.hero ? cur.hero[1] : '');
    heroText.appendChild(heroTitle);
    heroText.appendChild(heroSub);
    hero.appendChild(heroText);
    wrap.appendChild(hero);
    refs.heroTitle = heroTitle;
    refs.heroSub = heroSub;
    var themeCards = THEMES.map(function (t) {
      return makeThemeCard(t, function (id) {
        state.theme = id;
        save();
        apply();
        syncPanel();
      });
    });
    refs.themeCards = themeCards;

    var themeList = mk('div', 'general-settings-panel__group-card wb-fl-theme-list');
    themeCards.forEach(function (c) {
      themeList.appendChild(c.node);
    });
    var themeGroup = mk('div', 'general-settings-panel__group');
    themeGroup.appendChild(mk('p', 'general-settings-panel__group-label', '主题'));
    themeGroup.appendChild(themeList);
    wrap.appendChild(themeGroup);

    // —— 选中主题自己的设置 ——
    var seg = makeSeg(
      [
        { v: 'dark', label: '暗夜' },
        { v: 'light', label: '白昼' },
        { v: 'auto', label: '跟随应用' },
      ],
      state.mode,
      function (v) {
        state.mode = v;
        save();
        apply();
        seg.sync(v);
        refs.note.innerHTML = noteHTML();
      }
    );
    refs.seg = seg;

    var swChibi = makeSwitch(state.chibi, function (v) {
      state.chibi = v;
      save();
      apply();
    });
    var swGarland = makeSwitch(state.garland, function (v) {
      state.garland = v;
      save();
      apply();
    });
    var swBg = makeSwitch(state.bg, function (v) {
      state.bg = v;
      save();
      apply();
    });
    refs.swChibi = swChibi;
    refs.swGarland = swGarland;
    refs.swBg = swBg;

    // 装饰开关按**槽位名**索引 —— 两套主题共用同一批槽位，
    // 只有文案不同（芙兰叫"顶部水晶吊串"，鲸鱼叫"上升气泡"，其实是同一个位置）。
    refs.decoSwitches = { chibi: swChibi, garland: swGarland, bg: swBg };

    // 段标题与行文案都跟着主题走，所以不用 makeGroup，手工拼一遍好留引用。
    var themeSettings = mk('div', 'general-settings-panel__group wb-fl-theme-settings');
    var tsLabel = mk('p', 'general-settings-panel__group-label', decoTitleOf(cur));
    var tsCard = mk('div', 'general-settings-panel__group-card');
    // 第 0 行永远是「配色模式」，后面按主题的 deco 清单动态补
    tsCard.appendChild(
      makeRow('配色模式', '「跟随应用」会跟着 WorkBuddy 自己的深色 / 浅色走', seg.node)
    );
    themeSettings.appendChild(tsLabel);
    themeSettings.appendChild(tsCard);
    refs.themeSettings = themeSettings;
    refs.tsLabel = tsLabel;
    refs.tsCard = tsCard;
    refs.decoRows = [];
    refs.decoSig = null; // 强制首次 syncThemeSettings 走"重建"分支
    wrap.appendChild(themeSettings);

    /* ── ② 插件 ────────────────────────────────────────────────────────
       与主题无关、可以独立开关的小功能。 */
    var swClock = makeSwitch(state.clock, function (v) {
      state.clock = v;
      save();
      apply();
    });
    refs.swClock = swClock;

    wrap.appendChild(
      makeGroup('插件', [makeRow('桌面时钟', '可拖动的玻璃时钟，双击收起', swClock.node)])
    );

    var note = mk('p', 'wb-fl-panel__note');
    refs.note = note;
    note.innerHTML = noteHTML();
    wrap.appendChild(note);

    scroll.appendChild(wrap);
    panel.appendChild(scroll);
    panel.__flRefs = refs;
    return panel;
  }

  function noteHTML() {
    if (!themeOn()) {
      return '当前使用<b>原生外观</b> —— 主题的装饰与插件都已停用，随时可以切回来。';
    }
    var m = effectiveMode();
    var label = m === 'light' ? '白昼（浅色 / 黑字）' : '暗夜（深色 / 白字）';
    var how = state.mode === 'auto' ? '跟随应用' : '手动锁定';
    return (
      '当前主题：<b>' +
      activeTheme().name +
      '</b> · ' +
      label +
      '（' +
      how +
      '）。改动即时生效，不需要重启应用。'
    );
  }

  // 头图 + "XX主题设置"段：文案与行清单都跟着当前主题走。
  // ⚠ 槽位集合变了才重建 DOM，否则只改文案 —— 每次 syncPanel 都重建会把
  //   开关的 checked 状态和焦点冲掉。
  function syncThemeSettings() {
    if (!panelNode || !panelNode.__flRefs) return;
    var r = panelNode.__flRefs;
    var cur = activeTheme();

    r.heroTitle.textContent = cur.hero ? cur.hero[0] : cur.name;
    r.heroSub.textContent = cur.hero ? cur.hero[1] : '';
    r.tsLabel.textContent = decoTitleOf(cur);

    var sig = cur.deco
      .map(function (d) {
        return d.key;
      })
      .join(',');
    if (sig !== r.decoSig) {
      r.decoSig = sig;
      while (r.tsCard.children.length > 1) r.tsCard.removeChild(r.tsCard.lastChild);
      r.decoRows = [];
      cur.deco.forEach(function (it) {
        var sw = r.decoSwitches[it.key];
        if (!sw) return; // 清单里写了个没实现的槽位：跳过，不炸
        var row = makeDecoRow(it, sw.node);
        r.tsCard.appendChild(row.node);
        r.decoRows.push({ key: it.key, ref: row });
      });
    } else {
      var byKey = {};
      cur.deco.forEach(function (it) {
        byKey[it.key] = it;
      });
      r.decoRows.forEach(function (d) {
        if (byKey[d.key]) d.ref.set(byKey[d.key]);
      });
    }
  }

  function syncPanel() {
    if (!panelNode || !panelNode.__flRefs) return;
    var r = panelNode.__flRefs;
    r.themeCards.forEach(function (c) {
      c.sync(state.theme);
    });
    r.seg.sync(state.mode);
    r.swChibi.input.checked = !!state.chibi;
    r.swGarland.input.checked = !!state.garland;
    r.swBg.input.checked = !!state.bg;
    r.swClock.input.checked = !!state.clock;
    syncThemeSettings();
    // 主题没生效时，把"该主题自己的设置"整段收起来（CSS 管显隐）
    panelNode.setAttribute('data-theme-on', themeOn() ? '1' : '0');
    r.note.innerHTML = noteHTML();
  }

  function findNav() {
    return document.querySelector('.settings-navigation');
  }

  function injectNav() {
    var nav = findNav();
    if (!nav) return;
    if (nav.querySelector('[data-wb-fl-nav]')) return;
    // 第一个 group = "通用"，「外观」也在这一组里
    var group = nav.querySelector('.settings-navigation__group');
    if (!group) return;

    var btn = document.createElement('button');
    btn.type = 'button';
    btn.className = 'settings-navigation__item';
    btn.setAttribute('data-wb-fl-nav', '1');
    var icon = mk('span', 'settings-navigation__icon');
    icon.innerHTML = NAV_ICON;
    btn.appendChild(icon);
    btn.appendChild(mk('span', 'settings-navigation__label', '芽'));
    btn.appendChild(mk('span', 'wb-fl-nav-dot'));
    btn.addEventListener('click', function (e) {
      e.preventDefault();
      e.stopPropagation();
      openPanel();
    });
    group.appendChild(btn);
  }

  // 打开设置时如果原生导航项被点，要收回我们的面板
  function onModalClick(e) {
    var t = e.target;
    if (!t || !t.closest) return;
    if (t.closest('[data-wb-fl-nav]')) return;
    if (t.closest('[data-wb-fl-panel]')) return;
    if (t.closest('.settings-navigation__item') || t.closest('.settings-modal__close')) {
      closePanel();
    }
  }

  function ensurePanel() {
    var content = document.querySelector('.settings-modal__content');
    if (!content) return null;
    if (panelNode && panelNode.isConnected && panelNode.parentNode === content) return panelNode;
    panelNode = buildPanel();
    content.appendChild(panelNode);
    return panelNode;
  }

  function openPanel() {
    var content = document.querySelector('.settings-modal__content');
    if (!content) return;
    var panel = ensurePanel();
    if (!panel) return;

    var nav = findNav();
    if (nav) {
      [].forEach.call(nav.querySelectorAll('.settings-navigation__item'), function (b) {
        b.classList.remove('settings-navigation__item--active');
      });
      var mine = nav.querySelector('[data-wb-fl-nav]');
      if (mine) mine.classList.add('settings-navigation__item--active');
    }

    var nativePanel = content.querySelector('.settings-modal__panel');
    if (nativePanel) nativePanel.style.display = 'none';
    syncPanel();
    panel.style.display = '';
    panelActive = true;
  }

  function closePanel() {
    if (!panelActive) return;
    panelActive = false;
    if (panelNode) panelNode.style.display = 'none';
    var content = document.querySelector('.settings-modal__content');
    if (content) {
      var nativePanel = content.querySelector('.settings-modal__panel');
      if (nativePanel) nativePanel.style.display = '';
    }
    var nav = findNav();
    if (nav) {
      var mine = nav.querySelector('[data-wb-fl-nav]');
      if (mine) mine.classList.remove('settings-navigation__item--active');
    }
  }

  // 面板打开期间，React 可能把 --active 重新加回原生条目上 —— 盯着抹掉
  var navObs = new MutationObserver(function () {
    if (!panelActive) return;
    var nav = findNav();
    if (!nav) return;
    [].forEach.call(nav.querySelectorAll('.settings-navigation__item--active'), function (b) {
      if (!b.hasAttribute('data-wb-fl-nav')) b.classList.remove('settings-navigation__item--active');
    });
  });

  function tickSettings() {
    var modal = document.querySelector('.settings-modal');
    if (!modal) {
      if (panelActive) panelActive = false;
      panelNode = null;
      return;
    }
    injectNav();
    navObs.observe(modal, { subtree: true, attributes: true, attributeFilter: ['class'] });
    // 我们的面板跟着弹窗一起被 React 卸载 → 重开时要重建
    if (panelActive && (!panelNode || !panelNode.isConnected)) {
      panelActive = false;
      panelNode = null;
      openPanel();
    }
  }

  /* ─────────────────────────── 6. 启动 ─────────────────────────────────── */
  function boot() {
    apply();
    watchBody();
    syncModules();

    document.addEventListener('click', onModalClick, true);

    // 设置弹窗是后开的（打开时 body 会变），靠下面的观察者兜住；
    // 但启动那一刻如果弹窗已经开着，观察者不会触发 —— 先补一次。
    tickSettings();

    // SPA 路由切换 / React 重渲染会把节点带走，盯着塞回去
    var pending = false;
    function tick(fn) {
      return function () {
        if (pending) return;
        pending = true;
        requestAnimationFrame(function () {
          pending = false;
          fn();
        });
      };
    }
    var remount = tick(function () {
      syncModules();
      tickSettings();
    });
    var replace = tick(place);

    new MutationObserver(remount).observe(document.body, { childList: true, subtree: true });

    // 窗口尺寸变化 / 任何容器滚动都会让输入卡片移位，坐标要跟着重算
    window.addEventListener('resize', replace, { passive: true });
    window.addEventListener('scroll', replace, { passive: true, capture: true });
    // 输入框自己长高（多行输入）也要跟
    if (window.ResizeObserver) new ResizeObserver(replace).observe(document.body);
  }

  if (document.body) boot();
  else document.addEventListener('DOMContentLoaded', boot);

  // 调试入口：控制台里 __WB_FLANDRE_SET__(key, value) 可直接改设置
  window.__WB_FLANDRE_SET__ = function (k, v) {
    // 兼容旧调试口：__WB_FLANDRE_SET__('enabled', false) → theme = 'none'
    if (k === 'enabled') {
      k = 'theme';
      v = v ? 'flandre' : 'none';
    }
    if (typeof DEFAULTS[k] === 'undefined') return state;
    state[k] = v;
    save();
    apply();
    syncPanel();
    return state;
  };
  window.__WB_FLANDRE_GET__ = function () {
    var o = {};
    for (var k in state) o[k] = state[k];
    o.effective = effectiveMode();
    o.enabled = themeOn(); // 派生值，只读
    return o;
  };
})();
