@echo off
rem Console to UTF-8 so the Node output (Chinese) renders correctly.
rem This file itself is pure ASCII, so this cannot break cmd parsing.
chcp 65001 >nul 2>&1
setlocal enabledelayedexpansion
cd /d "%~dp0"

echo.
echo  ==============================================
echo   Flandre Theme  -  WorkBuddy Installer
echo  ==============================================
echo.

rem ---- locate node ----------------------------------------
set "NODE_BIN="
where node >nul 2>&1 && set "NODE_BIN=node"

if not defined NODE_BIN (
  for %%P in (
    "%ProgramFiles%\nodejs\node.exe"
    "%ProgramFiles(x86)%\nodejs\node.exe"
    "%LOCALAPPDATA%\Programs\nodejs\node.exe"
    "%APPDATA%\npm\node.exe"
  ) do (
    if not defined NODE_BIN if exist %%P set "NODE_BIN=%%~P"
  )
)

if not defined NODE_BIN (
  echo  [X] Node.js not found.
  echo.
  echo      This installer needs Node.js. Please install the LTS
  echo      version from https://nodejs.org and run this file again.
  echo.
  goto :hold
)

echo  [OK] Node.js: !NODE_BIN!
echo.

echo  ---- Step 1/3: pre-check ^(read-only, changes nothing^) ----
echo.
"!NODE_BIN!" "tools\install.mjs" --check
if errorlevel 1 (
  echo.
  echo  [X] Pre-check FAILED. Nothing was modified.
  echo      Please send the output above to whoever gave you this theme.
  goto :hold
)

echo.
echo  ---- Step 2/3: make sure WorkBuddy is closed ----
echo.
call :closeapp WorkBuddy.exe
call :closeapp WorkBuddyAI.exe

echo.
echo  ---- Step 3/3: install ----
echo.
"!NODE_BIN!" "tools\install.mjs" --reap
if errorlevel 1 (
  echo.
  echo  [X] Install FAILED. It was rolled back automatically;
  echo      your WorkBuddy should be unchanged.
  echo      Please send the output above to whoever gave you this theme.
  goto :hold
)

echo.
echo  ==============================================
echo   [OK] Done. Open WorkBuddy to see the theme.
echo.
echo   Notes:
echo     - Do NOT delete or move this folder (the theme loads from it)
echo     - To uninstall, run the uninstall .cmd in this folder
echo     - If a WorkBuddy update removes the theme, just run this again
echo  ==============================================
echo.
goto :hold

rem ---- helper: ask + force-close one process ------------------------------
:closeapp
tasklist /FI "IMAGENAME eq %1" 2>nul | find /I "%1" >nul
if errorlevel 1 goto :eof
echo  [!] %1 is running.
echo      Install requires it to be FULLY closed, including the
echo      tray icon ^(right-click -^> Exit^), not just the window X.
echo.
choice /C YN /M "      Force-close it now and continue? [Y/N]"
if errorlevel 2 goto :eof
taskkill /F /T /IM %1 >nul 2>&1
echo      Closed. Waiting 5s for antivirus scan to finish...
timeout /t 5 /nobreak >nul
goto :eof

:hold
echo.
pause
endlocal
