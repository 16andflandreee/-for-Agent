# 芙兰朵露 · WorkBuddy 主题

给腾讯 **WorkBuddy 桌面版**换一套暗红 + 金 + 哥特风格的皮肤。

---

## 这是什么

一个**第三方 UI 主题**，通过原地改写 WorkBuddy 的 `app.asar` 注入进去。
不改功能、不碰你的数据、不联网，只改外观。

> ⚠️ 这是**非官方**改动。它会被 WorkBuddy 的版本升级覆盖，升级后重装一次即可。

---

## 仓库里有什么

```
workbuddy-flandre-theme/          ← GitHub 仓库
├── README.md                    本文件（仓库首页）
├── LICENSE                      许可
├── AI-INSTALL.md                写给 AI 的安装说明
├── install.cmd / uninstall.cmd  Windows 一键安装 / 卸载
├── skin/                        主题本体（CSS / JS / 素材）
└── tools/
    ├── install.mjs              安装器
    └── locate.mjs               自动探测 WorkBuddy 安装目录
```

**成品下载在右侧 [Releases](../../releases)** —— 下载 `芙兰朵露主题-WorkBuddy-v1.0.zip`，解压即用。
仓库里其余文件是同一份内容的源码，方便直接看和改。

---

## 怎么装

### 路线 A：交给 AI 装（推荐）

1. 下载并解压 `芙兰朵露主题-WorkBuddy-v1.0.zip` 到一个**不会被删、不会被挪**的目录（例如 `D:\flandre-theme`）。
2. 把解压出来的目录整个丢给你的 AI 助手（Claude / Cursor / WorkBuddy 等），说一句：

   > 帮我按 `AI-INSTALL.md` 把这个主题装上

`AI-INSTALL.md` 是专门写给 AI 看的，里面写清了所有坑、验证步骤和回滚方式。

### 路线 B：自己装（三步）

**前置**：装 [Node.js](https://nodejs.org)（18 或更高）。

```bash
# 1. 完全退出 WorkBuddy（含托盘图标，右键 → 退出）
# 2. 体检（只读，不改任何东西）
node tools/install.mjs --check

# 3. 安装
node tools/install.mjs
```

看到 `✅ 两层校验全部对齐 —— 可以启动应用了` 就成了，重新打开 WorkBuddy。

> 如果提示找不到安装目录，或者装了两个版本，用 `--app-root` 指定：
> ```bash
> node tools/install.mjs --app-root="D:/你的路径/WorkBuddy"
> ```

Windows 用户也可以直接双击 `install.cmd`（会自己找 Node、自己提示关掉 WorkBuddy）。

---

## 怎么卸

```bash
node tools/install.mjs --uninstall
```

一键还原成官方原样。或者双击 `uninstall.cmd`。

---

## 怎么调

主题的真身全在 `skin/` 目录里：

| 文件 | 作用 |
|---|---|
| `theme.css` | 全部配色与样式（改这个就行） |
| `client.js` | 交互逻辑：设置面板、时钟浮层、立绘气泡 |
| `*.png` / `*.webp` | 立绘、翅膀、背景图 |

**改完 `skin/theme.css` 后重启应用就生效，不需要重新安装。**
（因为 asar 里注入的只是一条指向这个目录的引用。）

设置面板在应用内部调出，可以切换：主题（芙兰朵露 / 大肥鱼 / 关闭）、
明暗模式、立绘显隐、背景显隐、桌面时钟等。

---

## 如果提示"已经装着主题，但没有原版备份"

说明这份 WorkBuddy 之前装过主题，而原版文件没留下来。
安装器会先去常见位置**自动找**匹配的备份（找到就直接用）；找不到时会拒绝继续，
并列出几个选项。

其中 `--adopt` 可以从当前状态**反推**一份"近似原版"：

```bash
node tools/install.mjs --adopt
```

⚠️ **代价**：注入时被删掉的一小段中文注释无法恢复，所以这份"近似原版"
和官方原版不是逐字节相同（长度一致、功能一致）。将来卸载还原的是它。
如果更在意"能正常用"，可以用；否则优先重装一次 WorkBuddy 更干净。

---

## 重要提醒

1. **这个文件夹别删、别挪。** 主题是从这里加载的。删了/挪了主题会失效
   （WorkBuddy 本身不受影响，只是恢复原样）。
   如果非要挪，挪完重新跑一次 `node tools/install.mjs --reinstall`。
2. **WorkBuddy 升级后**主题可能失效，重新装一次即可。
3. **卸载前不要删 `backup/` 目录** —— 里面是原版备份，卸载靠它还原。
4. 安装必须**完全退出 WorkBuddy**（含托盘），否则写不进去。

---

## 目录结构

```
flandre-theme/
├── AI-INSTALL.md      给 AI 的安装说明（最重要）
├── README.md          本文件
├── LICENSE            许可
├── install.cmd        Windows 一键安装
├── uninstall.cmd      Windows 一键卸载
├── skin/              主题本体（CSS / JS / 素材）
└── tools/
    ├── install.mjs    安装器
    └── locate.mjs     自动探测 WorkBuddy 安装目录
```

`backup/` 目录是**首次安装时自动生成**的，里面是原版文件，卸载时要用。

---

## 安全说明

安装器做的事，只有这三件：

1. 在 `resources/app.asar` 里的 `renderer/index.html` 注入两行引用（严格等长，不影响其它文件）
2. 同步更新 asar header 里该文件的哈希（第一层完整性校验）
3. 同步更新 exe 里的期望哈希（第二层完整性校验）

除此之外不动任何文件。全过程有：

- **写前闸门** —— 文件被占用就一个字节都不动
- **三件套备份** —— 原版 index.html / header / exe 全部落盘
- **写后回读** —— 按真规则重算两层哈希，不是"应该没问题"
- **失败自动回滚** —— 任何一步不过，原样盖回去

---

## 许可

主题美术资源与代码仅供个人学习使用。
「芙兰朵露·斯卡蕾特」相关角色形象版权归 **上海爱丽丝幻乐团（上海アリス幻樂団）** 所有。
本主题与腾讯 WorkBuddy 官方无关。
